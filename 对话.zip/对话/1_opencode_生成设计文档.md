# 基于owner的agent隔离设计文档

**Session ID:** ses_247bd0995ffe0WMOqIE2GSxJDO
**Created:** 2026/4/23 10:54:49
**Updated:** 2026/4/23 11:00:15

---

## User

我现在要实现需求，根据owner对agent进行隔离操作，你帮我编写设计文档，要求如下：
1、注册rest接口，从证书中解析CN字段作为agent owner，入库保存
2、删除、修改 rest接口，从证书中解析CN字段，校验与库中agent owner的匹配项
3、注册接口有两种存储agent模式，文件模式如何根据owner存储，我还没想好，你可以给点建议 

---

## Assistant (Build · GLM-5 · 121.4s)

_Thinking:_

用户需要我帮忙编写一个设计文档，关于根据owner对agent进行隔离操作。需求包括：
1. 注册REST接口，从证书中解析CN字段作为agent owner，入库保存
2. 删除、修改REST接口，从证书中解析CN字段，校验与库中agent owner的匹配项
3. 注册接口有两种存储agent模式，文件模式如何根据owner存储，需要建议

首先我需要了解当前的代码库结构，看看现有的实现是什么样的，然后才能给出合理的设计文档。

让我先探索一下代码库的结构。

我先了解一下项目的代码结构，再帮你编写设计文档。

**Tool: task**

**Input:**
```json
{
  "description": "探索项目代码结构",
  "prompt": "探索这个项目的代码结构，重点了解：\n1. 现有的REST接口定义在哪里\n2. agent的注册、删除、修改相关代码\n3. agent的存储模式（文件模式和数据库模式）\n4. 证书相关的处理逻辑\n5. 数据模型定义\n\n请返回关键文件路径和简要说明。",
  "subagent_type": "explore"
}
```

**Output:**
```
task_id: ses_247bce499ffescw5BpdKHwgrDz (for resuming to continue this task if needed)

<task_result>
现在我已经完成了对项目代码结构的探索。以下是关键文件路径和简要说明：

---

## 项目代码结构分析报告

### 1. REST接口定义

**主文件：** `C:\Users\c30028839\Desktop\code\A2A\agent-registry_v1\agent_registry\server.py`

**说明：** 使用FastAPI框架实现REST API，提供以下接口：
- `POST /rest/a2a-t/v1/agents/register` - 注册Agent
- `GET /rest/a2a-t/v1/agents/query` - 精确查询Agent
- `PUT /rest/a2a-t/v1/update_agent/{name}` - 更新Agent
- `DELETE /rest/a2a-t/v1/deregister_agent/{name}` - 注销Agent
- `GET /rest/a2a-t/v1/agents/retrieve` - 语义模糊检索
- `GET /rest/a2a-t/v1/agents/{name}` - 按name和organization获取单个Agent

**特性：** 包含限流控制、请求大小检查、并发度控制、认证鉴权等中间件。

---

### 2. Agent注册、删除、修改相关代码

**核心业务文件：**
| 文件路径 | 说明 |
|---------|------|
| `agent_registry/core.py` | RegistryCore类，实现register、update、deregister、find_exact等核心方法 |
| `agent_registry/registry_instance.py` | 单例模式管理RegistryCore实例 |
| `common/custom/custom_handle.py` | HandlerRegistry处理各类业务操作（Insert、Query、Update、Deregister等） |

**核心类：** `RegistryCore` - 管理Agent的增删改查操作，使用(name, organization)作为唯一键。

---

### 3. Agent存储模式（文件模式和数据库模式）

**存储抽象层：**

| 文件路径 | 说明 |
|---------|------|
| `agent_registry/persistence/base.py` | StorageBackend抽象基类，定义CRUD接口 |
| `agent_registry/persistence/__init__.py` | StorageRegistry注册表，动态加载存储实现 |
| `agent_registry/persistence/file_storage.py` | FileStorage - JSON文件存储实现 |
| `agent_registry/persistence/postgresql_storage.py` | PostgreSQLStorage - PostgreSQL数据库存储实现 |
| `agent_registry/persistence/sql_queries.py` | SQL语句集中管理（预编译防注入） |

**配置文件：** `agent_registry/config.py` - 定义PERSISTENCE_MODE等配置项

**设计文档：** `database-persistence-design.md` - 详细描述了数据库持久化方案设计

**支持模式：**
- `file` - JSON文件存储（默认）
- `postgresql` - PostgreSQL数据库存储
- `vectordb` - 向量数据库存储（Milvus，用于语义检索）

---

### 4. 证书相关处理逻辑

**证书工具目录：** `common/cert/`

| 文件路径 | 说明 |
|---------|------|
| `common/cert/certificate_generator.py` | CertificateGenerator - 自签名证书生成（TLS证书和签名证书） |
| `common/cert/cert_validater.py` | CertValidator - 证书验证（格式、有效期、密钥长度、私钥匹配等） |
| `common/cert/cert_parser.py` | parse_cer_certificate、parse_pem_files - 解析CER/PEM证书 |
| `common/cert/x509_obj.py` | X509Obj、CertObj - X.509证书对象封装 |
| `common/cert/cert_exception.py` | CertParseException - 证书解析异常 |

**初始化配置：** `agent_registry/init.py` - InitCommand类，交互式配置TLS证书和签名证书

**验证要求：**
- RSA密钥 >= 3072 bits
- ECDSA密钥 >= 256 bits
- X.509v3格式
- 有效期校验
- CRL吊销列表支持

---

### 5. 数据模型定义

**AgentCard数据模型：**

| 文件路径 | 说明 |
|---------|------|
| `agent_registry/model/validated_agentcard.py` | validate_agent_card - AgentCard字段验证（长度、格式、危险字符等） |
| `agent_registry/signature/models.py` | JWK、JWKS、SignatureObject、ProtectedHeader - 签名相关数据模型 |

**核心验证函数：**
- `validate_name()` - 名称验证（字母、数字、下划线、空格）
- `validate_description()` - 描述长度限制
- `validate_provider()` - Provider验证（organization、url）
- `validate_skills()` - Skills数量和长度限制
- `validate_capabilities()` - Capabilities扩展限制

**限制参数：**
- NAME_MAX_LENGTH = 100
- ORGNIZATION_MAX_LENGTH = 100
- DESCRIPTION_MAX_LENGTH = 1000
- URL_MAX_LENGTH = 1024
- MAX_NUMBER_OF_SKILLS = 100

---

### 6. 签名验证相关

**签名目录：** `agent_registry/signature/`

| 文件路径 | 说明 |
|---------|------|
| `agent_registry/signature/agent_card_signature_validator.py` | AgentCardSignatureValidator - AgentCard签名验证器 |
| `agent_registry/signature/jwk_fetcher.py` | JWKFetcher - 从JWKS URL或后台获取公钥 |
| `agent_registry/signature/public_key_manager.py` | PublicKeyManager - 公钥管理（添加、删除、获取） |
| `agent_registry/signature/storage.py` | StoragePath - 公钥存储路径管理 |
| `agent_registry/signature/models.py` | 签名相关Pydantic模型 |

**验签流程：**
1. 先尝试从后台公钥存储获取公钥验证
2. 再尝试从jku（JWKS URL）获取公钥验证
3. 支持ES256（ECDSA）和RS256（RSA）算法

---

### 7. 其他关键文件

| 文件路径 | 说明 |
|---------|------|
| `agent_registry/config.py` | 全局配置常量定义 |
| `common/custom/interface_type.py` | InterfaceType枚举（INSERT、QUERY、UPDATE等） |
| `common/util/authenticate_util.py` | 认证鉴权工具 |
| `common/util/cipher_util.py` | 加密解密工具（AES-256） |
| `common/log/audit_logger.py` | 审计日志 |
| `common/vector_db/` | 向量数据库客户端（Milvus）和嵌入模型（BGE-M3） |

---

### 项目整体架构图

```
agent_registry_v1/
├── agent_registry/
│   ├── server.py          # REST API入口
│   ├── core.py            # 核心注册逻辑
│   ├── registry_instance.py # 单例管理
│   ├── init.py            # 初始化配置命令
│   ├── config.py          # 配置常量
│   ├── persistence.py     # 文件存储工具函数
│   ├── persistence/
│   │   ├── base.py        # 存储抽象基类
│   │   ├── __init__.py    # 存储注册表
│   │   ├── file_storage.py  # JSON文件存储
│   │   ├── postgresql_storage.py # PostgreSQL存储
│   │   └── sql_queries.py # SQL语句管理
│   ├── signature/
│   │   ├── agent_card_signature_validator.py # 签名验证
│   │   ├── jwk_fetcher.py # JWK获取器
│   │   ├── public_key_manager.py # 公钥管理
│   │   ├── storage.py    # 公钥存储路径
│   │   └── models.py     # 签名数据模型
│   └── model/
│       └── validated_agentcard.py # AgentCard验证
├── common/
│   ├── cert/              # 证书处理模块
│   ├── custom/            # 自定义处理器注册
│   ├── util/              # 工具类
│   ├── log/               # 日志
│   ├── llm/               # LLM调用
│   └── vector_db/         # 向量数据库
├── etc/
│   └ conf/                # 配置文件目录
├── data/                  # 数据存储目录
├── tests/                 # 测试文件
└── database-persistence-design.md # 数据库设计文档
```
</task_result>
```

---

## Assistant (Build · GLM-5 · 7.3s)

_Thinking:_

现在我对项目结构有了清晰的理解。让我阅读一些关键文件来更好地理解现有实现，特别是：

1. server.py - REST接口定义
2. core.py - 核心业务逻辑
3. 存储相关的实现
4. 证书解析相关代码

这样我可以编写一个符合现有架构的设计文档。

让我进一步查看几个关键文件的具体实现：

**Tool: read**

**Input:**
```json
{
  "filePath": "C:\\Users\\c30028839\\Desktop\\code\\A2A\\agent-registry_v1\\agent_registry\\server.py"
}
```

**Output:**
```
<path>C:\Users\c30028839\Desktop\code\A2A\agent-registry_v1\agent_registry\server.py</path>
<type>file</type>
<content>
1: # Copyright (c) 2026 Huawei Technologies Co., Ltd.
2: # All Rights Reserved.
3: #
4: #    Licensed under the Apache License, Version 2.0 (the "License"); you may
5: #    not use this file except in compliance with the License. You may obtain
6: #    a copy of the License at
7: #
8: #         http://www.apache.org/licenses/LICENSE-2.0
9: #
10: #    Unless required by applicable law or agreed to in writing, software
11: #    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
12: #    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
13: #    License for the specific language governing permissions and limitations
14: #    under the License.
15: 
16: # agent_registry/server.py
17: """
18: Agent Registry Service - RESTful API for managing AI Agent cards.
19: 
20: This module provides a FastAPI application with endpoints for registering
21: and querying agents. It includes rate limiting, request size checks,
22: and persistence using a JSON file.
23: """
24: 
25: import asyncio
26: from functools import partial
27: from typing import Optional, Tuple, Any
28: 
29: import anyio
30: from a2a.types import AgentCard
31: from fastapi import FastAPI, HTTPException, Query, Request, Depends, status, Path
32: from fastapi.responses import JSONResponse
33: from google.protobuf.json_format import Parse, MessageToDict
34: from loguru import logger
35: from limits import strategies, storage, parse_many
36: 
37: from starlette.responses import Response
38: 
39: from agent_registry.config import (
40:     MAX_REQUEST_BODY_SIZE,
41:     MAX_URL_LENGTH, CONN_TIMEOUT, CONN_MAX, FLOW_CTL_PARALLEL_REGISTER, FLOW_CTL_PARALLEL_QUERY, FLOW_CTL_REGISTER,
42:     FLOW_CTL_QUERY, AGENT_NUM_MAX, FLOW_CTL_PARALLEL_UPDATE, FLOW_CTL_PARALLEL_GET, FLOW_CTL_PARALLEL_RETRIEVE,
43:     FLOW_CTL_PARALLEL_DEREGISTER, FLOW_CTL_UPDATE, FLOW_CTL_GET, FLOW_CTL_RETRIEVE, FLOW_CTL_DEREGISTER,
44:     FLOW_CTL_JWK, FLOW_CTL_PARALLEL_JWK,
45: )
46: from agent_registry.core import RegistryCore
47: from agent_registry.model.validated_agentcard import validate_agent_card
48: from agent_registry.registry_instance import get_registry, initialize_registry
49: from agent_registry.middleware import ConnectionLimitMiddleware, TimeoutMiddleware
50: 
51: from common.custom.custom_handle import HandlerRegistry
52: from common.custom.interface_type import InterfaceType
53: from common.log.audit_logger import OperationResult, LogLevel, OperatorObject, OperationName
54: from common.util.config_util import get_conf
55: 
56: # ---------- Rate Limiter Setup (In-Memory) ----------
57: # Use in-memory storage for single-node deployments. Counts reset on restart.
58: sync_storage = storage.MemoryStorage()
59: # Moving window strategy provides smoother rate limiting.
60: limiter = strategies.MovingWindowRateLimiter(sync_storage)
61: 
62: audit_handle = HandlerRegistry.get_handler(InterfaceType.AUDIT)
63: 
64: 
65: def parse_rate_limit(interface_name: str):
66:     """
67:     Parse rate limit for the given interface name and return a RateLimitItem.
68:     Returns None if parsing fails or interface is unknown.
69:     The rate value is read from config with a default of 10, and unit is fixed to "/second".
70:     """
71:     # Mapping from interface name to config key and default value
72:     config_map = {
73:         "register": (FLOW_CTL_REGISTER, 50),
74:         "query": (FLOW_CTL_QUERY, 100),
75:         "update": (FLOW_CTL_UPDATE, 100),
76:         "get": (FLOW_CTL_GET, 100),
77:         "retrieve": (FLOW_CTL_RETRIEVE, 100),
78:         "deregister": (FLOW_CTL_DEREGISTER, 50),
79:         "jwk": (FLOW_CTL_JWK, 10),
80:     }
81: 
82:     # Get the corresponding config entry
83:     entry = config_map.get(interface_name)
84:     if entry is None:
85:         logger.warning(f"Unknown interface '{interface_name}', cannot get rate limit")
86:         return None
87: 
88:     key, default_value = entry
89:     try:
90:         # Read config value and convert to int; fallback to default if invalid
91:         rate_value = int(config.get(key, default_value))
92:     except (ValueError, TypeError):
93:         logger.error(f"Config key '{key}' has invalid value, using default {default_value}")
94:         rate_value = default_value
95: 
96:     rate_string = f"{rate_value}/second"
97:     try:
98:         items = parse_many(rate_string)
99:         return items[0] if items else None
100:     except Exception as e:
101:         logger.error(f"Failed to parse rate limit string '{rate_string}': {e}")
102:         return None
103: 
104: 
105: async def async_hit(rate_item, *identifiers: str, cost=1) -> bool:
106:     """
107:     Asynchronously call the synchronous limiter.hit() using a thread pool.
108:     This prevents blocking the event loop, though the operation is fast in memory.
109:     """
110:     func = partial(limiter.hit, rate_item, *identifiers, cost=cost)
111:     return await asyncio.to_thread(func)
112: 
113: 
114: class RateLimiter:
115:     """
116:     FastAPI dependency for rate limiting requests based on client IP.
117:     Uses X-Forwarded-For header when behind a proxy.
118:     """
119: 
120:     def __init__(self, interface_name: str = None):
121:         self.rate_item = parse_rate_limit(interface_name)
122:         if not self.rate_item:
123:             raise ValueError("Invalid rate limit configuration")
124: 
125:     async def __call__(self, request: Request):
126:         # Determine client identifier: prefer X-Forwarded-For, fallback to direct IP.
127:         identifier = request.client.host
128:         # Check rate limit; if exceeded, raise 429.
129:         if not await async_hit(self.rate_item, identifier):
130:             raise HTTPException(
131:                 status_code=status.HTTP_429_TOO_MANY_REQUESTS,
132:                 detail="Too Many Requests"
133:             )
134:         return True
135: 
136: 
137: # ---------- FastAPI Application ----------
138: app = FastAPI(
139:     title="Agent Registry Service",
140:     description="RESTful API for managing AI Agent cards with persistence and semantic search.",
141:     version="2.0.0",
142:     docs_url=None,
143:     redoc_url=None,
144:     openapi_url=None
145: )
146: 
147: config = get_conf()
148: 
149: app.add_middleware(
150:     ConnectionLimitMiddleware,
151:     max_connections=int(config.get(CONN_MAX, 11))
152: )
153: 
154: app.add_middleware(
155:     TimeoutMiddleware,
156:     timeout_seconds=int(config.get(CONN_TIMEOUT, 30))
157: )
158: 
159: register_semaphore = anyio.Semaphore(int(config.get(FLOW_CTL_PARALLEL_REGISTER, 50)))
160: query_semaphore = anyio.Semaphore(int(config.get(FLOW_CTL_PARALLEL_QUERY, 100)))
161: update_semaphore = anyio.Semaphore(int(config.get(FLOW_CTL_PARALLEL_UPDATE, 100)))
162: get_semaphore = anyio.Semaphore(int(config.get(FLOW_CTL_PARALLEL_GET, 100)))
163: retrieve_semaphore = anyio.Semaphore(int(config.get(FLOW_CTL_PARALLEL_RETRIEVE, 100)))
164: deregister_semaphore = anyio.Semaphore(int(config.get(FLOW_CTL_PARALLEL_DEREGISTER, 50)))
165: jwk_semaphore = anyio.Semaphore(int(config.get(FLOW_CTL_PARALLEL_JWK, 1)))
166: 
167: 
168: # ---------- Middleware ----------
169: @app.middleware("http")
170: async def security_middleware(request: Request, call_next):
171:     """
172:     Middleware for basic security checks:
173:     - Limit request body size for POST/PUT.
174:     - Limit total URL length.
175:     """
176:     # URL length check (full URL including scheme and host)
177:     # Using str(request.url) gives the complete URL string.
178:     if len(str(request.url)) > MAX_URL_LENGTH:
179:         return Response(
180:             content="URI Too Long",
181:             status_code=status.HTTP_414_URI_TOO_LONG,
182:         )
183:     # Body size check for write methods
184:     if request.method in ("POST", "PUT"):
185:         total_size = 0
186:         body_chunks = []
187: 
188:         try:
189:             # Stream body in chunks
190:             async for chunk in request.stream():
191:                 total_size += len(chunk)
192: 
193:                 # Early exit if size exceeds limit
194:                 if total_size > MAX_REQUEST_BODY_SIZE:
195:                     return Response(
196:                         content=f"Request body is too large, maximum allowed {MAX_REQUEST_BODY_SIZE // 1024} KB",
197:                         status_code=status.HTTP_413_CONTENT_TOO_LARGE,
198:                     )
199: 
200:                 body_chunks.append(chunk)
201:             request._body = b''.join(body_chunks)
202:         except Exception:
203:             return Response(
204:                 content="Bad Request",
205:                 status_code=status.HTTP_400_BAD_REQUEST,
206:             )
207: 
208:     return await call_next(request)
209: 
210: 
211: # ---------- Routes ----------
212: async def _check_agent_limit(registry: RegistryCore, client_ip: str, details: dict) -> None:
213:     """检查注册数量是否超过上限，若超过则记录审计日志并抛出异常。"""
214:     if len(registry.get_agents()) >= int(config.get(AGENT_NUM_MAX, 40)):
215:         details["message"] = "Agent registration limit exceeded."
216:         await audit_handle.handle({
217:             "operation_name": OperationName.REGISTER_AGENT,
218:             "level": LogLevel.MINOR,
219:             "result": OperationResult.FAILURE,
220:             "object_name": OperatorObject.AGENT,
221:             "details": details,
222:             "client_ip": client_ip
223:         })
224:         raise HTTPException(
225:             status_code=status.HTTP_409_CONFLICT,
226:             detail="Agent registration limit exceeded.",
227:         )
228: 
229: 
230: async def _check_duplicate_agent(agent: AgentCard, registry: RegistryCore, client_ip: str,
231:                                  details: dict) -> None:
232:     """检查是否已存在相同 (name, organization) 的 agent，若存在则记录并抛出异常。"""
233:     key = _make_agent_key(agent.name, agent.provider.organization)
234:     if key in registry.get_agents():
235:         details["message"] = "Registration skipped: duplicate agent."
236:         await audit_handle.handle({
237:             "operation_name": OperationName.REGISTER_AGENT,
238:             "level": LogLevel.MINOR,
239:             "result": OperationResult.FAILURE,
240:             "object_name": OperatorObject.AGENT,
241:             "details": details,
242:             "client_ip": client_ip
243:         })
244:         raise HTTPException(
245:             status_code=status.HTTP_409_CONFLICT,
246:             detail=f"Registration skipped: duplicate agent ({agent.name}, {agent.provider.organization})",
247:         )
248: 
249: 
250: async def _perform_registration(
251:         agent: AgentCard,
252:         client_ip: str,
253:         details: dict,
254: ) -> bool:
255:     """执行实际的注册操作，处理可能的 ValueError 和其他异常，并记录对应日志。"""
256:     try:
257:         save_handle = HandlerRegistry.get_handler(InterfaceType.INSERT)
258:         success = await save_handle.handle(agent)
259:         await audit_handle.handle({
260:             "operation_name": OperationName.REGISTER_AGENT,
261:             "level": LogLevel.MINOR,
262:             "result": OperationResult.SUCCESS,
263:             "object_name": OperatorObject.AGENT,
264:             "details": details,
265:             "client_ip": client_ip
266:         })
267:         return success
268:     except ValueError as e:
269:         details["message"] = str(e)
270:         await audit_handle.handle({
271:             "operation_name": OperationName.REGISTER_AGENT,
272:             "level": LogLevel.MINOR,
273:             "result": OperationResult.FAILURE,
274:             "object_name": OperatorObject.AGENT,
275:             "details": details,
276:             "client_ip": client_ip
277:         })
278:         raise HTTPException(
279:             status_code=status.HTTP_400_BAD_REQUEST, detail=str(e)
280:         ) from e
281:     except Exception as e:
282:         await audit_handle.handle({
283:             "operation_name": OperationName.REGISTER_AGENT,
284:             "level": LogLevel.MINOR,
285:             "result": OperationResult.FAILURE,
286:             "object_name": OperatorObject.AGENT,
287:             "details": details,
288:             "client_ip": client_ip
289:         })
290:         logger.error(f"Unexpected error in register: {e}")
291:         raise HTTPException(
292:             status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
293:             detail="Internal server error",
294:         ) from e
295: 
296: 
297: async def _perform_update(
298:         client_ip: str,
299:         name: str,
300:         organization: str,
301:         data: dict,
302:         details: dict
303: ) -> bool:
304:     """执行实际的更新操作，处理可能的 ValueError 和其他异常，并记录对应日志。"""
305:     try:
306:         update_handle = HandlerRegistry.get_handler(InterfaceType.UPDATE)
307:         success = await update_handle.handle(name, organization, data)
308:         await audit_handle.handle({
309:             "operation_name": OperationName.REGISTER_AGENT,
310:             "level": LogLevel.MINOR,
311:             "result": OperationResult.SUCCESS,
312:             "object_name": OperatorObject.AGENT,
313:             "details": data,
314:             "client_ip": client_ip
315:         })
316:         return success
317:     except ValueError as e:
318:         details["message"] = str(e)
319:         await audit_handle.handle({
320:             "operation_name": OperationName.REGISTER_AGENT,
321:             "level": LogLevel.MINOR,
322:             "result": OperationResult.FAILURE,
323:             "object_name": OperatorObject.AGENT,
324:             "details": details,
325:             "client_ip": client_ip
326:         })
327:         raise HTTPException(
328:             status_code=status.HTTP_400_BAD_REQUEST, detail=str(e)
329:         ) from e
330:     except Exception as e:
331:         await audit_handle.handle({
332:             "operation_name": OperationName.REGISTER_AGENT,
333:             "level": LogLevel.MINOR,
334:             "result": OperationResult.FAILURE,
335:             "object_name": OperatorObject.AGENT,
336:             "details": details,
337:             "client_ip": client_ip
338:         })
339:         logger.error(f"Unexpected error in update: {e}")
340:         raise HTTPException(
341:             status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
342:             detail="Internal server error",
343:         ) from e
344: 
345: 
346: @app.post(
347:     "/rest/a2a-t/v1/agents/register",
348:     response_model=bool,
349:     summary="Register a new agent",
350:     status_code=status.HTTP_201_CREATED,
351: )
352: async def register_agent(
353: 
354:         request: Request,
355:         _: Any = Depends(RateLimiter('register')),
356:         registry: RegistryCore = Depends(get_registry),
357: ):
358:     """
359:     Register a new agent.
360:     The combination (name, provider.organization) must be unique.
361:     Returns True if registered, False if duplicate.
362:     """
363:     body = await request.body()
364:     agent = Parse(body, AgentCard())
365:     client_ip = request.client.host
366:     details = {
367:         "agentName": agent.name,
368:         "organization": agent.provider.organization,
369:         "url": agent.provider.url,
370:     }
371:     authenticate_handle = HandlerRegistry.get_handler(InterfaceType.AUTHENTICATE)
372:     await authenticate_handle.handle(client_ip, request)
373:     acquired = False
374:     try:
375:         register_semaphore.acquire_nowait()
376:         acquired = True
377:         await _check_agent_limit(registry, client_ip, details)
378:         await _check_duplicate_agent(agent, registry, client_ip, details)
379:         validate_agent_card(agent)
380:         result = await _perform_registration(agent, client_ip, details)
381:         return JSONResponse(
382:             content=result,
383:             status_code=status.HTTP_201_CREATED,
384:         )
385:     except anyio.WouldBlock as e:
386:         raise HTTPException(status.HTTP_503_SERVICE_UNAVAILABLE, "Server is busy") from e
387:     finally:
388:         if acquired:
389:             register_semaphore.release()
390: 
391: 
392: @app.get(
393:     "/rest/a2a-t/v1/agents/query",
394:     response_model=None,
395:     summary="Exact search",
396: )
397: async def list_agents_exact(
398:         request: Request,
399:         name: Optional[str] = Query(None, description="Exact agent name"),
400:         organization: Optional[str] = Query(None, description="Exact organization"),
401:         _: Any = Depends(RateLimiter('query')),
402: ):
403:     """
404:     Search agents by exact fields (AND combination).
405:     All parameters are optional. If none provided, returns all agents.
406:     """
407:     client_ip = request.client.host
408:     authenticate_handle = HandlerRegistry.get_handler(InterfaceType.AUTHENTICATE)
409:     await authenticate_handle.handle(client_ip, request)
410:     acquired = False
411:     try:
412:         query_semaphore.acquire_nowait()
413:         acquired = True
414:         try:
415:             query_handle = HandlerRegistry.get_handler(InterfaceType.QUERY)
416:             agents = await query_handle.handle(name, organization)
417:             return [MessageToDict(card, preserving_proto_field_name=True) for card in agents]
418:         except Exception as e:
419:             logger.error(f"Error in exact search: {e}")
420:             raise HTTPException(
421:                 status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
422:                 detail="Internal server error",
423:             ) from e
424:     except anyio.WouldBlock as e:
425:         raise HTTPException(status.HTTP_503_SERVICE_UNAVAILABLE, "Server is busy") from e
426:     finally:
427:         if acquired:
428:             query_semaphore.release()
429: 
430: 
431: @app.put("/rest/a2a-t/v1/update_agent/{name}", response_model=bool, summary="Full update(replace) an agent")
432: async def update_agent(
433:         request: Request,
434:         name: str,
435:         organization: str,
436: 
437:         registry: RegistryCore = Depends(get_registry), _: Any = Depends(RateLimiter('update'))
438: ):
439:     """
440:     Fully replace an existing agent. The name and organization in the body must match the path/query.
441:     Returns True if updated, False if not found.
442:     """
443:     body = await request.body()
444:     agent_data = Parse(body, AgentCard())
445:     client_ip = request.client.host
446:     details = {
447:         "agentName": agent_data.name,
448:         "organization": agent_data.provider.organization,
449:         "url": agent_data.provider.url,
450:     }
451:     authenticate_handle = HandlerRegistry.get_handler(InterfaceType.AUTHENTICATE)
452:     await authenticate_handle.handle(client_ip, request)
453:     acquired = False
454:     try:
455:         # Convert to dict for update
456:         update_semaphore.acquire_nowait()
457:         acquired = True
458:         validate_agent_card(agent_data)
459:         await _check_agent_limit(registry, client_ip, details)
460: 
461:         data = MessageToDict(agent_data, preserving_proto_field_name=True)
462:         success = await _perform_update(client_ip, name, organization, data, details)
463:         if not success:
464:             raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Agent not found")
465:         return success
466:     except ValueError as e:
467:         raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e)) from e
468:     except Exception as e:
469:         logger.error(f"Unexpected error in full update:{e}")
470:         raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Internal server error") from e
471:     finally:
472:         if acquired:
473:             update_semaphore.release()
474: 
475: 
476: @app.delete("/rest/a2a-t/v1/deregister_agent/{name}", response_model=bool, summary="Deregister an agent")
477: async def deregister_agent(
478:         request: Request,
479:         name: str = Path(..., description="Agent name"),
480:         organization: str = Query(..., description="Agent organization"),
481:         _: Any = Depends(RateLimiter('deregister'))
482: ):
483:     """
484:     Remove an agent from the registry.
485:     Returns True if deleted, False if not found.
486:     """
487:     client_ip = request.client.host
488:     authenticate_handle = HandlerRegistry.get_handler(InterfaceType.AUTHENTICATE)
489:     await authenticate_handle.handle(client_ip, request)
490:     acquired = False
491:     try:
492:         deregister_semaphore.acquire_nowait()
493:         acquired = True
494:         try:
495:             deregister_handle = HandlerRegistry.get_handler(InterfaceType.DEREGISTER)
496:             agents = await deregister_handle.handle(name, organization)
497:             return agents
498:         except Exception as e:
499:             logger.error(f"Error in exact search: {e}")
500:             raise HTTPException(
501:                 status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
502:                 detail="Internal server error",
503:             ) from e
504: 
505:         success = registry.deregister(name, organization)
506:         if not success:
507:             raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Agent not found")
508:         return success
509:     except anyio.WouldBlock as e:
510:         raise HTTPException(status.HTTP_503_SERVICE_UNAVAILABLE, "Server is busy") from e
511:     finally:
512:         if acquired:
513:             deregister_semaphore.release()
514: 
515: 
516: @app.get("/rest/a2a-t/v1/agents/retrieve", response_model=None, summary="Fuzzy retrieve by task")
517: async def retrieve_agents_by_task(
518:         request: Request,
519:         task: str = Query(..., description="Natural language task description"),
520:         top_n: int = 10,
521:         _: Any = Depends(RateLimiter('retrieve'))
522: ):
523:     """
524:     Find agents that are semantically relevant to the given task using LLM.
525:     """
526:     """
527:     Search a single agent by its unique key(name and organization).
528:     """
529:     client_ip = request.client.host
530:     authenticate_handle = HandlerRegistry.get_handler(InterfaceType.AUTHENTICATE)
531:     await authenticate_handle.handle(client_ip, request)
532:     acquired = False
533:     try:
534:         retrieve_semaphore.acquire_nowait()
535:         acquired = True
536:         try:
537:             retrieve_handle = HandlerRegistry.get_handler(InterfaceType.RETRIEVE)
538:             agents = await retrieve_handle.handle(task, top_n)
539:             return [MessageToDict(agent) for agent in agents]
540:         except Exception as e:
541:             logger.error(f"Error in exact search: {e}")
542:             raise HTTPException(
543:                 status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
544:                 detail="Internal server error",
545:             ) from e
546:     except anyio.WouldBlock as e:
547:         raise HTTPException(status.HTTP_503_SERVICE_UNAVAILABLE, "Server is busy") from e
548:     finally:
549:         if acquired:
550:             retrieve_semaphore.release()
551: 
552: 
553: @app.get("/rest/a2a-t/v1/agents/{name}", response_model=None, summary="Get agent by exact name and organization")
554: async def get_agent(
555:         request: Request,
556:         name: str,
557:         organization: str, _: Any = Depends(RateLimiter('get'))
558: ):
559:     """
560:     Search a single agent by its unique key(name and organization).
561:     """
562:     client_ip = request.client.host
563:     authenticate_handle = HandlerRegistry.get_handler(InterfaceType.AUTHENTICATE)
564:     await authenticate_handle.handle(client_ip, request)
565:     acquired = False
566:     try:
567:         get_semaphore.acquire_nowait()
568:         acquired = True
569:         try:
570:             get_handle = HandlerRegistry.get_handler(InterfaceType.GET)
571:             agent = await get_handle.handle(name, organization)
572:             return MessageToDict(agent, preserving_proto_field_name=True) if agent is not None else None
573:         except Exception as e:
574:             logger.error(f"Error in exact search: {e}")
575:             raise HTTPException(
576:                 status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
577:                 detail="Internal server error",
578:             ) from e
579:     except anyio.WouldBlock as e:
580:         raise HTTPException(status.HTTP_503_SERVICE_UNAVAILABLE, "Server is busy") from e
581:     finally:
582:         if acquired:
583:             get_semaphore.release()
584: 
585: 
586: def close_registry():
587:     registry = get_registry()
588:     registry.close()
589: 
590: 
591: app.add_event_handler("startup", initialize_registry)
592: app.add_event_handler("shutdown", close_registry)
593: 
594: 
595: def _make_agent_key(name: str, organization: str) -> Tuple[str, str]:
596:     """Create a normalized key for indexing."""
597:     return name.strip(), organization.strip()

(End of file - total 597 lines)
</content>
```

**Tool: read**

**Input:**
```json
{
  "filePath": "C:\\Users\\c30028839\\Desktop\\code\\A2A\\agent-registry_v1\\agent_registry\\core.py"
}
```

**Output:**
```
<path>C:\Users\c30028839\Desktop\code\A2A\agent-registry_v1\agent_registry\core.py</path>
<type>file</type>
<content>
1: # Copyright (c) 2026 Huawei Technologies Co., Ltd.
2: # All Rights Reserved.
3: #
4: #    Licensed under the Apache License, Version 2.0 (the "License"); you may
5: #    not use this file except in compliance with the License. You may obtain
6: #    a copy of the License at
7: #
8: #         http://www.apache.org/licenses/LICENSE-2.0
9: #
10: #    Unless required by applicable law or agreed to in writing, software
11: #    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
12: #    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
13: #    License for the specific language governing permissions and limitations
14: #    under the License.
15: 
16: # agent_registry/core.py
17: import json
18: import os
19: from pathlib import Path
20: from threading import Lock
21: from typing import List, Dict, Tuple, Optional, Any
22: 
23: from a2a.types import AgentCard
24: from google.protobuf.json_format import MessageToDict
25: from loguru import logger
26: 
27: from agent_registry.config import PERSISTENCE_FILE, USE_VECTORDB, COLLECTION_NAME, PERSISTENCE_CONF, PERSISTENCE_MODE
28: from agent_registry.persistence import save_to_file, load_from_file
29: from agent_registry.persistence import StorageRegistry, StorageBackend
30: from agent_registry.prompts import build_agent_selection_prompt
31: from common.llm import get_llm_instance
32: from common.util.config_util import get_root_path
33: from common.vector_db.embedding_model.config.embedding_config import get_embedding_config_by_type, EmbeddingType
34: from common.vector_db.embedding_model.config.embedding_tool_registry import get_or_create_embedding_tool_instance
35: from common.vector_db.vector_db_client.config.vector_db_client_registry import get_or_create_vectordb_tool_instance
36: from common.vector_db.vector_db_client.config.vector_db_config import VectorDBType, get_vectordb_config_by_type
37: 
38: 
39: class RegistryCore:
40:     """
41:     Core registry that stores AgentCard instances with (name, organization) as unique key.
42:     Provides registration, update, deletion, exact search, and LLM-based fuzzy search.
43:     Supports persistence to a JSON file, PostgreSQL, or vectordb.
44:     """
45: 
46:     def __init__(self, persistence_file: str = PERSISTENCE_FILE, use_vectordb: bool = USE_VECTORDB,
47:                  persistence_mode: str = PERSISTENCE_MODE, persistence_conf: dict = PERSISTENCE_CONF):
48:         self.llm = get_llm_instance()
49:         self.use_vectordb = use_vectordb
50:         self.persistence_mode = persistence_mode
51:         self.persistence_conf = persistence_conf
52:         self.storage: Optional[StorageBackend] = None
53:         self._lock = Lock()
54: 
55:         if use_vectordb:
56:             self.vectordb = get_or_create_vectordb_tool_instance(get_vectordb_config_by_type(VectorDBType.Milvus))
57:             self.embedding_tool = get_or_create_embedding_tool_instance(
58:                 get_embedding_config_by_type(EmbeddingType.BGEM3))
59:         elif persistence_mode == 'postgresql':
60:             self.storage = StorageRegistry.get_backend(self.persistence_mode, self.persistence_conf)
61:             logger.info(f"Registry initialized with {self.persistence_mode} storage")
62:         else:
63:             data_path = Path(get_root_path()) / "data"
64:             data_path.mkdir(exist_ok=True)
65:             os.chmod(data_path, 0o700)
66:             self.persistence_file = str(data_path / persistence_file)
67:             self._agents: Dict[Tuple[str, str], AgentCard] = {}
68:             self._load()
69: 
70:     def initialize(self):
71:         """Initialize storage backend for PostgreSQL mode."""
72:         if not self.use_vectordb and self.persistence_mode == 'postgresql':
73:             if not self.storage:
74:                 self.storage = StorageRegistry.get_backend(self.persistence_mode, self.persistence_conf)
75:                 logger.info(f"Registry initialized with {self.persistence_mode} storage")
76: 
77:     def close(self):
78:         """Close storage backend connection."""
79:         if self.storage:
80:             self.storage.close()
81: 
82:     @staticmethod
83:     def _make_key(name: str, organization: str) -> Tuple[str, str]:
84:         """Create a normalized key for indexing."""
85:         return name.strip(), organization.strip()
86: 
87:     def register(self, agent: AgentCard, use_vectordb: bool = USE_VECTORDB) -> bool:
88:         """
89:         Register a new agent. Returns True if successful, False if duplicate.
90:         Raises ValueError if agent lacks required fields (name, provider.organization).
91:         """
92:         with self._lock:
93:             if use_vectordb:
94:                 entity_str = json.dumps(MessageToDict(agent, preserving_proto_field_name=True))
95:                 embedding = self.embedding_tool.get_embedding_vector(agent.description)
96:                 id = self._make_id(agent.name, agent.provider.organization)
97:                 insert_entity = {"embedding": embedding, "id": id, "name": agent.name, "description": agent.description,
98:                                  "organization": agent.provider.organization, "agent_card": entity_str}
99:                 insert_data = {"collection_name": COLLECTION_NAME, "entity": insert_entity}
100:                 return self.vectordb.insert_entity(insert_data)
101:             elif self.persistence_mode == 'postgresql':
102:                 return self.storage.create(agent)
103:             else:
104:                 key = self._make_key(agent.name, agent.provider.organization)
105:                 self._agents[key] = agent
106:                 self._save()
107:                 logger.info(f"Registered agent: {agent.name} (org={agent.provider.organization})")
108:                 return True
109: 
110:     def find_exact(self, name: Optional[str] = None, organization: Optional[str] = None,
111:                    use_vectordb: bool = USE_VECTORDB) -> List[AgentCard]:
112:         """
113:         Exact search based on name, organization, and provider (which is provider.organization).
114:         All parameters are optional; if multiple are given, they are combined with AND.
115:         """
116:         if use_vectordb:
117:             if name is not None and organization is not None:
118:                 query_data = {"collection_name": COLLECTION_NAME, "key": "id",
119:                               "value": self._make_id(name, organization)}
120:             elif name is not None:
121:                 query_data = {"collection_name": COLLECTION_NAME, "key": "name", "value": name}
122:             else:
123:                 query_data = {"collection_name": COLLECTION_NAME, "key": "organization", "value": organization}
124:             return self.vectordb.query_by_key(query_data)
125:         elif self.persistence_mode == 'postgresql':
126:             if name and organization:
127:                 result = self.storage.find_by_key(name, organization)
128:                 return [result] if result else []
129:             elif name:
130:                 return self.storage.find_by_name(name)
131:             elif organization:
132:                 return self.storage.find_by_organization(organization)
133:             return self.storage.find_all()
134:         else:
135:             result = []
136:             for agent in self._agents.values():
137:                 if name is not None and agent.name != name:
138:                     continue
139:                 if organization is not None and agent.provider.organization != organization:
140:                     continue
141:                 result.append(agent)
142:             return result
143: 
144:     def get_agents(self, use_vectordb: bool = USE_VECTORDB):
145:         if use_vectordb:
146:             return self.vectordb.get_all_entities({"collection_name": COLLECTION_NAME})
147:         elif self.persistence_mode == 'postgresql':
148:             return self.storage.find_all()
149:         else:
150:             return self._agents
151: 
152:     def update(self, name: str, organization: str, agent_data: Dict[str, Any],
153:                use_vectordb: bool = USE_VECTORDB) -> bool:
154:         """
155:         Update an existing agent.The primary key(name,organization) cannot be changed.
156:         Return True if successful, False if not found.
157:         """
158:         if use_vectordb:
159:             entity_str = json.dumps(agent_data)
160:             embedding = self.embedding_tool.get_embedding_vector(agent_data["description"])
161:             key = self._make_id(agent_data["name"], agent_data["provider"]["organization"])
162:             insert_entity = {"id": key, "embedding": embedding, "name": agent_data["name"],
163:                              "description": agent_data["description"],
164:                              "organization": agent_data["provider"]["organization"], "agent_card": entity_str}
165:             update_data = {"collection_name": COLLECTION_NAME, "entity": insert_entity}
166:             return self.vectordb.update_entity(update_data)
167:         elif self.persistence_mode == 'postgresql':
168:             return self.storage.update(name, organization, agent_data)
169:         else:
170:             key = self._make_key(name, organization)
171:             existing_agent = self._agents.get(key)
172:             if not existing_agent:
173:                 logger.info(f"Update failed: agent not found({name},{organization})")
174:                 return False
175: 
176:             updated_data = agent_data
177:             if updated_data.get("name") != name or updated_data.get("provider", {}).get("organization") != organization:
178:                 raise ValueError("Cannot change primary key(name or organization) during update.")
179: 
180:             try:
181:                 new_agent = AgentCard(**updated_data)
182:             except Exception as e:
183:                 logger.error(f"Invalid agent data for update: {e}")
184:                 raise ValueError(f"Invalid agent data: {e}") from e
185: 
186:             self._agents[key] = new_agent
187:             self._save()
188:             logger.info(f"Updated agent: {new_agent.name}(org={new_agent.provider.organization})")
189:             return True
190: 
191:     def deregister(self, name: str, organization: str, use_vectordb: bool = USE_VECTORDB) -> bool:
192:         """
193:         Remove an agent. Returns True if deleted, False if not found.
194:         """
195:         if use_vectordb:
196:             delete_data = {"collection_name": COLLECTION_NAME, "id": self._make_id(name, organization)}
197:             return self.vectordb.delete_entity(delete_data)
198:         elif self.persistence_mode == 'postgresql':
199:             return self.storage.delete(name, organization)
200:         else:
201:             key = self._make_key(name, organization)
202:             if key not in self._agents:
203:                 logger.info(f"Deregister failed: agent not found ({name},{organization})")
204:                 return False
205:             del self._agents[key]
206:             self._save()
207:             logger.info(f"Deregistered agent: {name}({organization})")
208:             return True
209: 
210:     def retrieve_by_task(self, task: str, top_n: int, use_vectordb: bool = USE_VECTORDB) -> List[AgentCard]:
211:         """
212:         Fuzzy retrieve using LLM to match task description with agent capabilities.
213:         Returns a list of candidate agents(could be empty).
214:         """
215:         agents_info = []
216:         if use_vectordb:
217:             retrieve_entity = {"collection_name": COLLECTION_NAME,
218:                                "embedding": self.embedding_tool.get_embedding_vector(task),
219:                                "top_n": top_n}
220:             retrieve_results = self.vectordb.retrieve_entity(retrieve_entity)
221:             for agent in retrieve_results:
222:                 agents_info.append({
223:                     "name": agent["name"],
224:                     "description": agent["description"],
225:                     "skills": [{"skill_name": s["name"], "skill_description": s["description"]} for s in
226:                                agent["skills"]] if agent["skills"] else []
227:                 })
228: 
229:             try:
230:                 prompt = build_agent_selection_prompt(task, json.dumps(agents_info, ensure_ascii=False, indent=2),
231:                                                       top_n=top_n)
232:                 _, selected_name_str = self.llm.ask_llm(prompt)
233:                 trans_table = str.maketrans("", "", "\"[]")
234:                 selected_names = [n.strip().translate(trans_table) for n in selected_name_str.split(",") if n.strip()]
235:             except Exception as e:
236:                 logger.error(f"LLM error during agent selection: {e}")
237:                 return []
238:             result = [agent for agent in retrieve_results if agent["name"] in selected_names]
239:             logger.info(f"LLM selected {len(result)} agents for task: {task}")
240:             return result
241:         elif self.persistence_mode == 'postgresql':
242:             agents = self.storage.find_all()
243:             if not task or not agents:
244:                 return []
245: 
246:             for agent in agents:
247:                 agents_info.append({
248:                     "name": agent.name,
249:                     "description": agent.description,
250:                     "skills": [{"skill_name": s.name, "skill_description": s.description} for s in
251:                                agent.skills] if agent.skills else []
252:                 })
253:             try:
254:                 prompt = build_agent_selection_prompt(task, json.dumps(agents_info, ensure_ascii=False, indent=2),
255:                                                       top_n=top_n)
256:                 _, selected_name_str = self.llm.ask_llm(prompt)
257:                 trans_table = str.maketrans("", "", "\"[]")
258:                 selected_names = [n.strip().translate(trans_table) for n in selected_name_str.split(",") if n.strip()]
259:             except Exception as e:
260:                 logger.error(f"LLM error during agent selection: {e}")
261:                 return []
262: 
263:             result = [agent for agent in agents if agent.name in selected_names]
264:             logger.info(f"LLM selected {len(result)} agents for task: {task}")
265:             return result
266:         else:
267:             if not task or not self._agents:
268:                 return []
269: 
270:             for agent in self._agents.values():
271:                 agents_info.append({
272:                     "name": agent.name,
273:                     "description": agent.description,
274:                     "skills": [{"skill_name": s.name, "skill_description": s.description} for s in
275:                                agent.skills] if agent.skills else []
276:                 })
277:             try:
278:                 prompt = build_agent_selection_prompt(task, json.dumps(agents_info, ensure_ascii=False, indent=2),
279:                                                       top_n=top_n)
280:                 _, selected_name_str = self.llm.ask_llm(prompt)
281:                 trans_table = str.maketrans("", "", "\"[]")
282:                 selected_names = [n.strip().translate(trans_table) for n in selected_name_str.split(",") if n.strip()]
283:             except Exception as e:
284:                 logger.error(f"LLM error during agent selection: {e}")
285:                 return []
286: 
287:             result = [agent for agent in self._agents.values() if agent.name in selected_names]
288:             logger.info(f"LLM selected {len(result)} agents for task: {task}")
289:             return result
290: 
291:     def get_by_key(self, name: str, organization: str, use_vectordb: bool = USE_VECTORDB) -> Optional[AgentCard]:
292:         """Search a single agent by exact name and organization."""
293:         if use_vectordb:
294:             query_data = {"collection_name": COLLECTION_NAME, "key": "id", "value": self._make_id(name, organization)}
295:             result = self.vectordb.query_by_key(query_data)
296:             if len(result) > 0:
297:                 return result[0]
298:             else:
299:                 return None
300:         elif self.persistence_mode == 'postgresql':
301:             return self.storage.find_by_key(name, organization)
302:         else:
303:             key = self._make_key(name, organization)
304:             return self._agents.get(key)
305: 
306:     def _save(self) -> None:
307:         """Persist current agents to file."""
308:         data = [MessageToDict(agent, preserving_proto_field_name=True) for agent in self._agents.values()]
309:         save_to_file(self.persistence_file, data)
310: 
311:     def _load(self) -> None:
312:         """Load agents from file and populate the dictionary."""
313:         data_list = load_from_file(self.persistence_file)
314:         for item in data_list:
315:             try:
316:                 agent = AgentCard(**item)
317:                 key = self._make_key(agent.name, agent.provider.organization)
318:                 self._agents[key] = agent
319:             except Exception as e:
320:                 logger.error(f"Failed to load agent from JSON: {e}, data: {item}")
321:         logger.info(f"Loaded {len(self._agents)} agents from persistence.")
322: 
323:     def _make_id(self, name: str, organization: str):
324:         return name + organization

(End of file - total 324 lines)
</content>
```

**Tool: read**

**Input:**
```json
{
  "filePath": "C:\\Users\\c30028839\\Desktop\\code\\A2A\\agent-registry_v1\\agent_registry\\persistence\\base.py"
}
```

**Output:**
```
<path>C:\Users\c30028839\Desktop\code\A2A\agent-registry_v1\agent_registry\persistence\base.py</path>
<type>file</type>
<content>
1: # Copyright (c) 2026 Huawei Technologies Co., Ltd.
2: # All Rights Reserved.
3: #
4: #    Licensed under the Apache License, Version 2.0 (the "License"); you may
5: #    not use this file except in compliance with the License. You may obtain
6: #    a copy of the License at
7: #
8: #         http://www.apache.org/licenses/LICENSE-2.0
9: #
10: #    Unless required by applicable law or agreed to in writing, software
11: #    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
12: #    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
13: #    License for the specific language governing permissions and limitations
14: #    under the License.
15: 
16: from abc import ABC, abstractmethod
17: from typing import List, Optional, Dict, Any
18: 
19: from a2a.types import AgentCard
20: 
21: 
22: class StorageBackend(ABC):
23:     @classmethod
24:     @abstractmethod
25:     def init(cls, config: dict) -> 'StorageBackend':
26:         pass
27: 
28:     @abstractmethod
29:     def create(self, agent: AgentCard) -> bool:
30:         pass
31: 
32:     @abstractmethod
33:     def find_by_key(self, name: str, organization: str) -> Optional[AgentCard]:
34:         pass
35: 
36:     @abstractmethod
37:     def find_by_name(self, name: str) -> List[AgentCard]:
38:         pass
39: 
40:     @abstractmethod
41:     def find_by_organization(self, organization: str) -> List[AgentCard]:
42:         pass
43: 
44:     @abstractmethod
45:     def find_all(self) -> List[AgentCard]:
46:         pass
47: 
48:     @abstractmethod
49:     def update(self, name: str, organization: str, agent_data: Dict[str, Any]) -> bool:
50:         pass
51: 
52:     @abstractmethod
53:     def delete(self, name: str, organization: str) -> bool:
54:         pass
55: 
56:     @abstractmethod
57:     def count(self) -> int:
58:         pass
59: 
60:     @abstractmethod
61:     def close(self):
62:         pass

(End of file - total 62 lines)
</content>
```

**Tool: read**

**Input:**
```json
{
  "filePath": "C:\\Users\\c30028839\\Desktop\\code\\A2A\\agent-registry_v1\\agent_registry\\persistence\\file_storage.py"
}
```

**Output:**
```
<path>C:\Users\c30028839\Desktop\code\A2A\agent-registry_v1\agent_registry\persistence\file_storage.py</path>
<type>file</type>
<content>
1: # Copyright (c) 2026 Huawei Technologies Co., Ltd.
2: # All Rights Reserved.
3: #
4: #    Licensed under the Apache License, Version 2.0 (the "License"); you may
5: #    not use this file except in compliance with the License. You may obtain
6: #    a copy of the License at
7: #
8: #         http://www.apache.org/licenses/LICENSE-2.0
9: #
10: #    Unless required by applicable law or agreed to in writing, software
11: #    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
12: #    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
13: #    License for the specific language governing permissions and limitations
14: #    under the License.
15: 
16: import json
17: import os
18: from datetime import datetime
19: from pathlib import Path
20: from typing import List, Optional, Dict, Any
21: 
22: from a2a.types import AgentCard
23: from google.protobuf.json_format import MessageToDict
24: from loguru import logger
25: 
26: from .base import StorageBackend
27: 
28: 
29: class FileStorage(StorageBackend):
30:     def __init__(self, file_path: str, max_file_size: int = 100 * 1024 * 1024):
31:         self.file_path = file_path
32:         self.max_file_size = max_file_size
33:         self._agents: Dict[tuple, AgentCard] = {}
34:         self._load()
35: 
36:     @classmethod
37:     def init(cls, config: dict) -> 'FileStorage':
38:         file_path = config.get('file.path', 'data/agentcard.json')
39:         max_file_size = config.get('max_file_size', 100 * 1024 * 1024)
40:         Path(file_path).parent.mkdir(parents=True, exist_ok=True)
41:         instance = cls(file_path, max_file_size)
42:         logger.info(f"FileStorage initialized with path: {file_path}")
43:         return instance
44: 
45:     def create(self, agent: AgentCard) -> bool:
46:         key = (agent.name.strip(), agent.provider.organization.strip())
47:         self._agents[key] = agent
48:         self._save()
49:         logger.info(f"Registered agent: {agent.name} (org={agent.provider.organization})")
50:         return True
51: 
52:     def find_by_key(self, name: str, organization: str) -> Optional[AgentCard]:
53:         key = (name.strip(), organization.strip())
54:         return self._agents.get(key)
55: 
56:     def find_by_name(self, name: str) -> List[AgentCard]:
57:         result = []
58:         for agent in self._agents.values():
59:             if name and agent.name == name:
60:                 result.append(agent)
61:         return result
62: 
63:     def find_by_organization(self, organization: str) -> List[AgentCard]:
64:         result = []
65:         for agent in self._agents.values():
66:             if organization and agent.provider.organization == organization:
67:                 result.append(agent)
68:         return result
69: 
70:     def find_all(self) -> List[AgentCard]:
71:         return list(self._agents.values())
72: 
73:     def update(self, name: str, organization: str, agent_data: Dict[str, Any]) -> bool:
74:         key = (name.strip(), organization.strip())
75:         existing_agent = self._agents.get(key)
76:         if not existing_agent:
77:             logger.info(f"Update failed: agent not found({name},{organization})")
78:             return False
79: 
80:         if agent_data.get("name") != name or agent_data.get("provider", {}).get("organization") != organization:
81:             raise ValueError("Cannot change primary key(name or organization) during update.")
82: 
83:         try:
84:             new_agent = AgentCard(**agent_data)
85:         except Exception as e:
86:             logger.error(f"Invalid agent data for update: {e}")
87:             raise ValueError(f"Invalid agent data: {e}") from e
88: 
89:         self._agents[key] = new_agent
90:         self._save()
91:         logger.info(f"Updated agent: {new_agent.name}(org={new_agent.provider.organization})")
92:         return True
93: 
94:     def delete(self, name: str, organization: str) -> bool:
95:         key = (name.strip(), organization.strip())
96:         if key not in self._agents:
97:             logger.info(f"Deregister failed: agent not found ({name},{organization})")
98:             return False
99:         del self._agents[key]
100:         self._save()
101:         logger.info(f"Deregistered agent: {name}({organization})")
102:         return True
103: 
104:     def count(self) -> int:
105:         return len(self._agents)
106: 
107:     def close(self):
108:         self._save()
109:         logger.info("FileStorage closed")
110: 
111:     def _save(self) -> None:
112:         data = [MessageToDict(agent, preserving_proto_field_name=True) for agent in self._agents.values()]
113:         json_str = json.dumps(data, ensure_ascii=False, indent=2)
114:         data_size = len(json_str.encode('utf-8'))
115:         if data_size > self.max_file_size:
116:             error_msg = f"Data size ({data_size} bytes) exceeds maximum allowed ({self.max_file_size} bytes)"
117:             logger.error(error_msg)
118:             raise ValueError(error_msg)
119: 
120:         Path(self.file_path).parent.mkdir(parents=True, exist_ok=True)
121:         with open(self.file_path, 'w', encoding='utf-8') as f:
122:             f.write(json_str)
123:         os.chmod(self.file_path, 0o600)
124:         logger.info(f"Saved {len(self._agents)} agents to {self.file_path} ({data_size} bytes)")
125: 
126:     def _load(self) -> None:
127:         if not os.path.exists(self.file_path):
128:             logger.warning(f"Persistence file {self.file_path} not found. Starting with empty registry.")
129:             return
130: 
131:         try:
132:             file_size = os.path.getsize(self.file_path)
133:             if file_size > self.max_file_size:
134:                 logger.error(f"File {self.file_path} size ({file_size} bytes) exceeds maximum allowed.")
135:                 return
136:         except OSError as e:
137:             logger.error(f"Failed to check file size for {self.file_path}: {e}")
138:             return
139: 
140:         try:
141:             with open(self.file_path, 'r', encoding='utf-8') as f:
142:                 data = json.load(f)
143:             if not isinstance(data, list):
144:                 logger.error(f"Invalid format in {self.file_path}: expected a list")
145:                 return
146:             for item in data:
147:                 try:
148:                     agent = AgentCard(**item)
149:                     key = (agent.name.strip(), agent.provider.organization.strip())
150:                     self._agents[key] = agent
151:                 except Exception as e:
152:                     logger.error(f"Failed to load agent from JSON: {e}, data: {item}")
153:             logger.info(f"Loaded {len(self._agents)} agents from {self.file_path}")
154:         except Exception as e:
155:             logger.error(f"Failed to load agents from {self.file_path}: {e}")

(End of file - total 155 lines)
</content>
```

**Tool: read**

**Input:**
```json
{
  "filePath": "C:\\Users\\c30028839\\Desktop\\code\\A2A\\agent-registry_v1\\common\\cert\\cert_parser.py"
}
```

**Output:**
```
<path>C:\Users\c30028839\Desktop\code\A2A\agent-registry_v1\common\cert\cert_parser.py</path>
<type>file</type>
<content>
1: # Copyright (c) 2026 Huawei Technologies Co., Ltd.
2: # All Rights Reserved.
3: #
4: #    Licensed under the Apache License, Version 2.0 (the "License"); you may
5: #    not use this file except in compliance with the License. You may obtain
6: #    a copy of the License at
7: #
8: #         http://www.apache.org/licenses/LICENSE-2.0
9: #
10: #    Unless required by applicable law or agreed to in writing, software
11: #    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
12: #    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
13: #    License for the specific language governing permissions and limitations
14: #    under the License.
15: 
16: from cryptography import x509
17: from cryptography.hazmat.primitives import serialization
18: from cryptography.hazmat.primitives.asymmetric.types import PrivateKeyTypes
19: 
20: from common.cert.cert_exception import CertParseException
21: from common.cert.x509_obj import X509Obj, CertObj
22: 
23: 
24: SM2_SIGN = '1.2.156.10197.1.501'
25: 
26: 
27: def parse_cer_certificate(cert_path: str) -> X509Obj:
28:     try:
29:         with open(cert_path, 'rb') as f:
30:             cert_data = f.read()
31: 
32:         if b"-----BEGIN " not in cert_data:
33:             # der二进制模式，不支持读取私钥
34:             raise CertParseException(f'Parse certificate error! "-----BEGIN" not found! Unsupported der binary type! ')
35:         # 尝试解析为证书
36:         cert_org_list = x509.load_pem_x509_certificates(cert_data)
37:         cer_obj_list = _extract_certificate_infos(cert_org_list)
38:         # cer对应的是信任证书，仅包含证书和公钥
39:         if len(cer_obj_list) == 0:
40:             raise CertParseException(f"Parse certificate error! No certificate found! ")
41:         # 有多个公钥
42:         x509_obj = X509Obj(cert_list=cer_obj_list)
43:         return x509_obj
44:     except Exception as e:
45:         exception = e
46:         if not isinstance(e, CertParseException):
47:             # 过滤原始解析异常信息，防止敏感信息泄漏
48:             exception = CertParseException("Parse certificate error! ")
49:         raise exception
50: 
51: 
52: def parse_pem_files(cert_path: str, password: bytes = None) -> PrivateKeyTypes:
53:     try:
54:         with open(cert_path, 'rb') as f:
55:             p12_data = f.read()
56: 
57:         # 使用cryptography解析私钥文件
58:         password_bytes = password
59:         private_key = serialization.load_pem_private_key(
60:             p12_data,
61:             password=password_bytes
62:         )
63: 
64:         # 处理证书
65:         if not private_key:
66:             raise CertParseException(f"Parse private key error! ")
67:         return private_key
68:     except Exception as e:
69:         exception = e
70:         if not isinstance(e, CertParseException):
71:             # 过滤原始解析异常信息，防止敏感信息泄漏
72:             exception = CertParseException("Parse private key error! ")
73:         raise exception
74: 
75: 
76: def _extract_certificate_infos(cert_list: list[x509.Certificate]) -> list[CertObj]:
77:     result = []
78:     for cert in cert_list:
79:         result.append(_extract_certificate_info(cert))
80:     return result
81: 
82: 
83: def _extract_certificate_info(cert: x509.Certificate) -> CertObj:
84:     """从cryptography证书对象中提取信息"""
85:     # 国密模式不支持
86:     if SM2_SIGN in cert.signature_algorithm_oid.dotted_string:
87:         raise CertParseException(f"Unsupported sm2 public key type: {SM2_SIGN}")
88:     info = {
89:         'subject': cert.subject.rfc4514_string(),
90:         'issuer': cert.issuer.rfc4514_string(),
91:         'serial_number': hex(cert.serial_number),
92:         'valid_from': cert.not_valid_before_utc.isoformat(),
93:         'valid_to': cert.not_valid_after_utc.isoformat(),
94:         'version': cert.version,
95:         'public_key': cert.public_key(),
96:         'org_cert': cert
97:     }
98:     obj = CertObj.from_dict(info)
99:     return obj
100: 
101: 
102: def parse_crl_list(cert_path: str) -> x509.CertificateRevocationList:
103:     try:
104:         with open(cert_path, 'rb') as f:
105:             cert_data = f.read()
106: 
107:         if b"-----BEGIN " not in cert_data:
108:             # der二进制模式，不支持读取der格式的crl
109:             raise CertParseException(f'Parse crl file error! "-----BEGIN" not found! Unsupported der binary type! ')
110:         # 尝试解析PEM格式的CRL
111:         crl_list = x509.load_pem_x509_crl(cert_data)
112:         if len(crl_list) == 0:
113:             raise CertParseException(f"Parse crl file error! No crl found! ")
114:         return crl_list
115:     except Exception as e:
116:         exception = e
117:         if not isinstance(e, CertParseException):
118:             # 过滤原始解析异常信息，防止敏感信息泄漏
119:             exception = CertParseException("Parse crl file error! ")
120:         raise exception

(End of file - total 120 lines)
</content>
```

---

## Assistant (Build · GLM-5 · 6.4s)

_Thinking:_

现在我对项目有了很好的了解。让我再看看postgresql_storage.py和x509_obj.py来完整理解数据库存储和证书对象的结构。

**Tool: read**

**Input:**
```json
{
  "filePath": "C:\\Users\\c30028839\\Desktop\\code\\A2A\\agent-registry_v1\\agent_registry\\persistence\\postgresql_storage.py"
}
```

**Output:**
```
<path>C:\Users\c30028839\Desktop\code\A2A\agent-registry_v1\agent_registry\persistence\postgresql_storage.py</path>
<type>file</type>
<content>
1: # Copyright (c) 2026 Huawei Technologies Co., Ltd.
2: # All Rights Reserved.
3: #
4: #    Licensed under the Apache License, Version 2.0 (the "License"); you may
5: #    not use this file except in compliance with the License. You may obtain
6: #    a copy of the License at
7: #
8: #         http://www.apache.org/licenses/LICENSE-2.0
9: #
10: #    Unless required by applicable law or agreed to in writing, software
11: #    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
12: #    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
13: #    License for the specific language governing permissions and limitations
14: #    under the License.
15: 
16: import json
17: from datetime import datetime
18: from typing import List, Optional, Dict, Any
19: 
20: import psycopg2
21: from psycopg2 import pool
22: from a2a.types import AgentCard
23: from google.protobuf.json_format import MessageToDict
24: from loguru import logger
25: 
26: from .base import StorageBackend
27: from .sql_queries import PostgreSQLQueries
28: 
29: 
30: class PostgreSQLStorage(StorageBackend):
31:     def __init__(self, pool: pool.ThreadedConnectionPool):
32:         self.pool = pool
33: 
34:     @classmethod
35:     def init(cls, config: dict) -> 'PostgreSQLStorage':
36:         host = config.get('postgresql.host', 'localhost')
37:         port = int(config.get('postgresql.port', 5432))
38:         database = config.get('postgresql.name', 'a2a_registry')
39:         user = config.get('postgresql.username', 'a2a_user')
40:         password = config.get('postgresql.password', '')
41:         min_size = int(config.get('postgresql.pool.min', 5))
42:         max_size = int(config.get('postgresql.pool.max', 20))
43: 
44:         cls._ensure_database_exists(host, port, database, user, password)
45: 
46:         connection_pool = pool.ThreadedConnectionPool(
47:             minconn=min_size,
48:             maxconn=max_size,
49:             host=host,
50:             port=port,
51:             database=database,
52:             user=user,
53:             password=password
54:         )
55:         logger.info("PostgreSQL connection pool initialized")
56: 
57:         cls._ensure_table_exists(connection_pool)
58: 
59:         return cls(connection_pool)
60: 
61:     @classmethod
62:     def _ensure_database_exists(cls, host: str, port: int, database: str, user: str, password: str):
63:         conn = psycopg2.connect(
64:             host=host,
65:             port=port,
66:             database='postgres',
67:             user=user,
68:             password=password
69:         )
70:         conn.autocommit = True
71:         try:
72:             with conn.cursor() as cur:
73:                 cur.execute("SELECT 1 FROM pg_database WHERE datname = %s", (database,))
74:                 exists = cur.fetchone()
75:                 if not exists:
76:                     cur.execute(f'CREATE DATABASE "{database}"')
77:                     logger.info(f"Database '{database}' created successfully")
78:         finally:
79:             conn.close()
80: 
81:     @classmethod
82:     def _ensure_table_exists(cls, connection_pool: pool.ThreadedConnectionPool):
83:         conn = connection_pool.getconn()
84:         conn.autocommit = True
85:         try:
86:             with conn.cursor() as cur:
87:                 cur.execute(PostgreSQLQueries.CREATE_TABLE.value)
88:                 cur.execute(PostgreSQLQueries.CREATE_INDEX_ORG.value)
89:                 cur.execute(PostgreSQLQueries.CREATE_INDEX_NAME.value)
90:                 cur.execute(PostgreSQLQueries.CREATE_INDEX_GIN.value)
91:                 logger.info("Table 'agent_card' and indexes created/verified")
92:         finally:
93:             connection_pool.putconn(conn)
94: 
95:     def _get_agent_fields(self, agent: AgentCard) -> tuple:
96:         agent_dict = MessageToDict(agent, preserving_proto_field_name=True)
97:         now = datetime.utcnow()
98:         return (
99:             agent.name,
100:             agent.provider.organization,
101:             agent_dict.get('description'),
102:             agent_dict.get('documentation_url'),
103:             agent_dict.get('version'),
104:             json.dumps(agent_dict.get('provider', {})),
105:             json.dumps(agent_dict.get('capabilities', {})) if agent_dict.get('capabilities') else None,
106:             json.dumps(agent_dict.get('skills', [])) if agent_dict.get('skills') else None,
107:             json.dumps(agent_dict.get('default_input_modes', [])) if agent_dict.get('default_input_modes') else None,
108:             json.dumps(agent_dict.get('default_output_modes', [])) if agent_dict.get('default_output_modes') else None,
109:             json.dumps(agent_dict),
110:             now,
111:             now
112:         )
113: 
114:     def create(self, agent: AgentCard) -> bool:
115:         conn = self.pool.getconn()
116:         try:
117:             with conn.cursor() as cur:
118:                 cur.execute(
119:                     PostgreSQLQueries.CREATE_AGENT.value,
120:                     self._get_agent_fields(agent)
121:                 )
122:                 conn.commit()
123:             result = self.find_by_key(agent.name, agent.provider.organization)
124:             return result is not None
125:         finally:
126:             self.pool.putconn(conn)
127: 
128:     def find_by_key(self, name: str, organization: str) -> Optional[AgentCard]:
129:         conn = self.pool.getconn()
130:         try:
131:             with conn.cursor() as cur:
132:                 cur.execute(
133:                     PostgreSQLQueries.FIND_BY_KEY.value,
134:                     (name, organization)
135:                 )
136:                 row = cur.fetchone()
137:             if row:
138:                 data = row[0] if isinstance(row[0], dict) else json.loads(row[0])
139:                 return AgentCard(**data)
140:             return None
141:         finally:
142:             self.pool.putconn(conn)
143: 
144:     def find_by_name(self, name: str) -> List[AgentCard]:
145:         conn = self.pool.getconn()
146:         try:
147:             with conn.cursor() as cur:
148:                 cur.execute(
149:                     PostgreSQLQueries.FIND_BY_NAME.value,
150:                     (f"%{name}%",)
151:                 )
152:                 rows = cur.fetchall()
153:             return [AgentCard(**(r[0] if isinstance(r[0], dict) else json.loads(r[0]))) for r in rows]
154:         finally:
155:             self.pool.putconn(conn)
156: 
157:     def find_by_organization(self, organization: str) -> List[AgentCard]:
158:         conn = self.pool.getconn()
159:         try:
160:             with conn.cursor() as cur:
161:                 cur.execute(
162:                     PostgreSQLQueries.FIND_BY_ORG.value,
163:                     (organization,)
164:                 )
165:                 rows = cur.fetchall()
166:             return [AgentCard(**(r[0] if isinstance(r[0], dict) else json.loads(r[0]))) for r in rows]
167:         finally:
168:             self.pool.putconn(conn)
169: 
170:     def find_all(self) -> List[AgentCard]:
171:         conn = self.pool.getconn()
172:         try:
173:             with conn.cursor() as cur:
174:                 cur.execute(PostgreSQLQueries.FIND_ALL.value)
175:                 rows = cur.fetchall()
176:             return [AgentCard(**(r[0] if isinstance(r[0], dict) else json.loads(r[0]))) for r in rows]
177:         finally:
178:             self.pool.putconn(conn)
179: 
180:     def update(self, name: str, organization: str, agent_data: Dict[str, Any]) -> bool:
181:         conn = self.pool.getconn()
182:         try:
183:             with conn.cursor() as cur:
184:                 agent = AgentCard(**agent_data)
185:                 agent_dict = MessageToDict(agent, preserving_proto_field_name=True)
186:                 now = datetime.utcnow()
187:                 cur.execute(
188:                     PostgreSQLQueries.UPDATE_AGENT.value,
189:                     (
190:                         json.dumps(agent_dict),
191:                         now,
192:                         name,
193:                         organization
194:                     )
195:                 )
196:                 conn.commit()
197:                 affected = cur.rowcount
198:             return affected > 0
199:         finally:
200:             self.pool.putconn(conn)
201: 
202:     def delete(self, name: str, organization: str) -> bool:
203:         conn = self.pool.getconn()
204:         try:
205:             with conn.cursor() as cur:
206:                 cur.execute(
207:                     PostgreSQLQueries.DELETE_AGENT.value,
208:                     (name, organization)
209:                 )
210:                 conn.commit()
211:                 affected = cur.rowcount
212:             return affected > 0
213:         finally:
214:             self.pool.putconn(conn)
215: 
216:     def count(self) -> int:
217:         conn = self.pool.getconn()
218:         try:
219:             with conn.cursor() as cur:
220:                 cur.execute(PostgreSQLQueries.COUNT.value)
221:                 result = cur.fetchone()
222:             return result[0] if result else 0
223:         finally:
224:             self.pool.putconn(conn)
225: 
226:     def close(self):
227:         if self.pool:
228:             self.pool.closeall()
229:             logger.info("PostgreSQL connection pool closed")

(End of file - total 229 lines)
</content>
```

**Tool: read**

**Input:**
```json
{
  "filePath": "C:\\Users\\c30028839\\Desktop\\code\\A2A\\agent-registry_v1\\common\\cert\\x509_obj.py"
}
```

**Output:**
```
<path>C:\Users\c30028839\Desktop\code\A2A\agent-registry_v1\common\cert\x509_obj.py</path>
<type>file</type>
<content>
1: # Copyright (c) 2026 Huawei Technologies Co., Ltd.
2: # All Rights Reserved.
3: #
4: #    Licensed under the Apache License, Version 2.0 (the "License"); you may
5: #    not use this file except in compliance with the License. You may obtain
6: #    a copy of the License at
7: #
8: #         http://www.apache.org/licenses/LICENSE-2.0
9: #
10: #    Unless required by applicable law or agreed to in writing, software
11: #    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
12: #    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
13: #    License for the specific language governing permissions and limitations
14: #    under the License.
15: 
16: 
17: class CertObj:
18:     subject = None
19:     issuer = None
20:     serial_number = None
21:     valid_from = None
22:     valid_to = None
23:     version = None
24:     public_key = None
25:     org_cert = None
26: 
27: 
28:     @classmethod
29:     def from_dict(cls, cert_dict):
30:         obj = cls()
31:         obj.subject = cert_dict.get('subject', '')
32:         obj.issuer = cert_dict.get('issuer', '')
33:         obj.serial_number = cert_dict.get('serial_number', '')
34:         obj.valid_from = cert_dict.get('valid_from', '')
35:         obj.valid_to = cert_dict.get('valid_to', '')
36:         obj.version = cert_dict.get('version', '')
37:         obj.public_key = cert_dict.get('public_key', None)
38:         obj.org_cert = cert_dict.get('org_cert', None)
39:         return obj
40: 
41: 
42: class X509Obj:
43:     private_key = None
44:     public_key = None
45:     cert_list = []
46: 
47:     def __init__(self, cert_list, private_key=None, public_key=None):
48:         self.cert_list = cert_list
49:         self.private_key = private_key
50:         self.public_key = public_key

(End of file - total 50 lines)
</content>
```

**Tool: read**

**Input:**
```json
{
  "filePath": "C:\\Users\\c30028839\\Desktop\\code\\A2A\\agent-registry_v1\\database-persistence-design.md"
}
```

**Output:**
```
<path>C:\Users\c30028839\Desktop\code\A2A\agent-registry_v1\database-persistence-design.md</path>
<type>file</type>
<content>
1: /new# Agent注册中心 数据库持久化方案设计
2: 
3: ## 0. 体系架构图
4: 
5: ```mermaid
6: graph TB
7:     subgraph Client
8:         A[Agent Client]
9:     end
10: 
11:     subgraph "Agent Registry"
12:         R["RegistryCore<br/>注册核心"]
13:         S["StorageRegistry<br/>存储注册表"]
14:         
15:         subgraph StorageBackends
16:             F["FileStorage<br/>文件存储"]
17:             P["PostgreSQLStorage<br/>PostgreSQL存储"]
18:         end
19:     end
20: 
21:     subgraph Config
22:         C["persistence.conf<br/>持久化配置"]
23:         I["init.py<br/>初始化命令"]
24:     end
25: 
26:     subgraph Database
27:         DB[(PostgreSQL<br/>14+)]
28:     end
29: 
30:     A --> R
31:     R -->|persistence.mode| S
32:     S -->|get_backend| F
33:     S -->|get_backend| P
34:     P -->|JDBC| DB
35:     I -.->|配置| C
36:     C -.->|读取| S
37: ```
38: 
39: ---
40: 
41: ## 1. 数据库选型
42: 
43: ### 推荐：PostgreSQL 14+
44: 
45: **理由**：
46: - 支持 `JSONB` 类型，完美适配 AgentCard 结构化数据
47: - GIN 索引加速 JSON 字段全文/条件查询
48: - 连接池成熟，适配多实例场景
49: - 单实例→多实例改造平滑（仅需修改连接配置）
50: 
51: ---
52: 
53: ## 2. 数据库单实例 vs 多实例推荐
54: 
55: ### 推荐方案：当前选择**单实例**，后续可平滑升级多实例
56: 
57: | 对比项 | 单实例 | 多实例（推荐过渡方案） |
58: |--------|--------|------------------------|
59: | 复杂度 | 低 | 中 |
60: | 成本 | 低 | 高（需增加资源） |
61: | 扩展性 | 有限 | 线性扩展 |
62: | 故障影响 | 单点故障 | 高可用 |
63: 
64: **单实例改造成多实例路径**：
65: ```
66: 当前：App(App1, App2, App3) → DB(单实例)
67: 
68: 升级路径1（推荐）：App → 中间件(pgbouncer) → DB(单实例) → 后续升级为DB主从
69: 
70: 升级路径2：App → DB(主从复制) → 只读副本扩展
71: ```
72: 
73: **结论**：当前选择单实例即可，PostgreSQL 原生支持主从复制，后续仅需：
74: 1. 部署 pgBouncer 作为连接池
75: 2. 配置主从复制
76: 3. 修改连接串指向 VIP 或 pgbouncer
77: 
78: ---
79: 
80: ## 3. 表结构设计
81: 
82: ### 3.1 主表：agent_card
83: 
84: ```sql
85: CREATE TABLE agent_card (
86:     id              SERIAL PRIMARY KEY,
87:     name            VARCHAR(100) NOT NULL,
88:     organization    VARCHAR(100) NOT NULL,
89:     description     VARCHAR(1000),
90:     url             VARCHAR(1024),
91:     version         VARCHAR(50),
92:     provider_json   JSONB        NOT NULL,
93:     capabilities_json JSONB,
94:     skills_json     JSONB,
95:     default_input_modes  JSONB,
96:     default_output_modes JSONB,
97:     agent_card_json JSONB        NOT NULL,
98:     created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
99:     updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
100:     UNIQUE(name, organization)
101: );
102: 
103: -- 索引
104: CREATE INDEX idx_agent_org ON agent_card(organization);
105: CREATE INDEX idx_agent_name ON agent_card(name);
106: CREATE INDEX idx_agent_card_json ON agent_card USING GIN(agent_card_json);
107: ```
108: 
109: ---
110: 
111: ## 4. 配置文件设计
112: 
113: ### 4.1 `etc/conf/persistence.conf`
114: 
115: ```properties
116: # 持久化模式：file / postgresql / sqlite / gauss
117: persistence.mode=file
118: 
119: # PostgreSQL 配置（当 persistence.mode=postgresql 时生效）
120: postgresql.host=${DB_HOST:localhost}
121: postgresql.port=${DB_PORT:5432}
122: postgresql.name=${DB_NAME:a2a_registry}
123: postgresql.username=${DB_USER:a2a_user}
124: postgresql.password=${DB_PASSWORD}
125: postgresql.pool.min=${DB_POOL_MIN:5}
126: postgresql.pool.max=${DB_POOL_MAX:20}
127: postgresql.pool.timeout=${DB_POOL_TIMEOUT:30}
128: 
129: # SQLite 配置（当 persistence.mode=sqlite 时生效）
130: sqlite.path=${SQLITE_PATH:data/agents.db}
131: 
132: # GaussDB 配置（当 persistence.mode=gauss 时生效）
133: gauss.host=${GAUSS_HOST:localhost}
134: gauss.port=${GAUSS_PORT:5432}
135: gauss.database=${GAUSS_DATABASE:a2a_registry}
136: gauss.username=${GAUSS_USER:a2a_user}
137: gauss.password=${GAUSS_PASSWORD}
138: ```
139: 
140: ---
141: 
142: ## 5. 多实例并发安全设计
143: 
144: ### 方案：应用层乐观锁 + 数据库唯一约束
145: 
146: ```python
147: async def register(agent: AgentCard):
148:     try:
149:         # 依赖数据库唯一约束 (name, organization) 保证幂等
150:         await db.execute("""
151:             INSERT INTO agent_card (name, organization, agent_card_json, ...)
152:             VALUES ($1, $2, $3, ...)
153:             ON CONFLICT (name, organization) DO NOTHING
154:         """)
155:     except UniqueViolationError:
156:         raise DuplicateAgentError()
157: ```
158: 
159: **多实例场景下的并发流程**：
160: 1. 实例A、实例B 同时注册 `agent-001` / `org-A`
161: 2. 数据库唯一约束生效，只有一个成功
162: 3. 另一个返回 "agent已存在"
163: 
164: ---
165: 
166: ## 6. 配置变更设计
167: 
168: ### 6.1 新增配置 `etc/conf/persistence.conf`
169: 
170: ```properties
171: # 持久化模式：file / postgresql / sqlite / gauss
172: persistence.mode=file
173: 
174: # PostgreSQL 配置（mode=postgresql 时生效）
175: postgresql.host=localhost
176: postgresql.port=5432
177: postgresql.name=a2a_registry
178: postgresql.username=a2a_user
179: postgresql.password=${DB_PASSWORD}
180: postgresql.pool.min=5
181: postgresql.pool.max=20
182: postgresql.pool.timeout=30
183: 
184: # SQLite 配置（mode=sqlite 时生效）
185: sqlite.path=data/agents.db
186: ```
187: 
188: ### 6.2 配置加载方式
189: 
190: ```python
191: # common/util/conf_util.py 新增方法
192: def get_persistence_conf() -> dict:
193:     """读取持久化配置，支持环境变量替换"""
194:     conf = _read_conf("etc/conf/persistence.conf")
195:     return _resolve_env_vars(conf)
196: ```
197: 
198: ### 6.3 持久化配置初始化
199: 
200: **Init 命令流程图**：
201: 
202: ```mermaid
203: flowchart TD
204:     A[运行 init 命令] --> B[现有配置: TLS & 签名]
205:     B --> C{选择 persistence.mode}
206:     
207:     C -->|file| D[保存 persistence.mode=file]
208:     C -->|postgresql| E[输入数据库口令]
209:     E --> F[加密口令 & 保存]
210:     
211:     D --> G[保存配置文件]
212:     F --> G
213:     G --> H[完成]
214:     
215:     style E fill:#f9f,stroke:#333,stroke-width:2px
216:     style F fill:#9f9,stroke:#333,stroke-width:2px
217: ```
218: 
219: **【第一阶段】** 复用现有的 `agent-registry-init` 命令机制，在交互式初始化过程的**最后**添加持久化配置步骤：
220: 1. 选择存储模式（`persistence.mode`）
221: 2. 如果选择 `postgresql` 模式，则进一步配置数据库口令（加密保存）
222: 
223: 其他 PostgreSQL 配置项（`host`、`port`、`name`、`username`、连接池配置等）通过直接修改配置文件实现。
224: 
225: **【第二阶段】** 可后续扩展 init 命令，支持完整配置项的交互式配置。
226: 
227: **实现设计（第一阶段）**：
228: 
229: 在现有的 `agent_registry/init.py` 的 `InitCommand` 类中添加持久化配置方法：
230: 
231: ```python
232: # agent_registry/init.py 新增方法
233: 
234: def config_persistence(self) -> dict:
235:     """配置持久化存储相关选项"""
236:     config = {}
237: 
238:     # 1. 选择存储模式
239:     default_mode = self.existing_config.get('persistence.mode', 'file')
240:     mode_input = input(
241:         f"\n请选择存储模式 persistence.mode (file/postgresql, 默认: {default_mode}): "
242:     ).strip()
243:     config['persistence.mode'] = mode_input or default_mode
244: 
245:     # 2. 如果选择 postgresql，则配置数据库口令
246:     if config['persistence.mode'] == 'postgresql':
247:         print("\n配置 PostgreSQL 数据库连接：")
248:         default_password = self.existing_config.get('postgresql.password', '')
249:         password_input = input(
250:             f"请输入数据库口令 postgresql.password: "
251:         ).strip()
252:         if password_input:
253:             from common.util.cipher_util import encrypt
254:             config['postgresql.password'] = encrypt(password_input)
255: 
256:     return config
257: ```
258: 
259: 修改 `init_command` 方法，将持久化配置放在**最后**（现有 TLS/签名配置之后）：
260: 
261: ```python
262: def init_command(self):
263:     config = {}
264: 
265:     # ... 现有 TLS/签名配置 ...
266: 
267:     # 【第一阶段】持久化配置（最后一步）
268:     # 1. 选择存储模式 (file/postgresql)
269:     # 2. 如果选择 postgresql，则配置数据库口令
270:     print("\n" + "="*50)
271:     print("持久化存储配置")
272:     print("="*50)
273:     persistence_config = self.config_persistence()
274:     config.update(persistence_config)
275: 
276:     self.save_config_to_file(config)
277: ```
278: 
279: **配置加密存储**：
280: 
281: ```python
282: # common/util/cipher_util.py 使用现有的加密方法
283: def encrypt(plaintext: str) -> str:
284:     # 实际实现使用 AES-256 加密
285:     return encrypted_string
286: ```
287: 
288: **配置加载时解密**：
289: 
290: ```python
291: # common/util/conf_util.py 新增方法
292: def get_persistence_conf() -> dict:
293:     conf = _read_conf("etc/conf/persistence.conf")
294:     conf = _resolve_env_vars(conf)
295:     # 解密数据库口令
296:     if 'postgresql.password' in conf:
297:         from common.util.cipher_util import decrypt
298:         conf['postgresql.password'] = decrypt(conf['postgresql.password'])
299:     return conf
300: ```
301: 
302: **第一阶段配置文件示例**：
303: 
304: ```properties
305: # etc/conf/persistence.conf
306: # 【第一阶段】通过 init 命令配置的项（自动生成）
307: persistence.mode=postgresql
308: postgresql.password=  # 通过 init 命令加密配置
309: 
310: # 【第一阶段】以下配置项需手动修改配置文件
311: postgresql.host=localhost
312: postgresql.port=5432
313: postgresql.name=a2a_registry
314: postgresql.username=a2a_user
315: 
316: postgresql.pool.min=5
317: postgresql.pool.max=20
318: postgresql.pool.timeout=30
319: ```
320: 
321: ---
322: 
323: ## 7. SQL 防注入设计
324: 
325: 所有数据库操作使用预编译语句（Prepared Statements），参数通过占位符传递，由数据库驱动层自动处理转义，彻底杜绝 SQL 注入。
326: 
327: ### 7.1 PostgreSQL 预编译模式
328: 
329: ```python
330: # 使用 $1, $2, $3 占位符，参数单独传递
331: await conn.execute("""
332:     INSERT INTO agent_card (name, organization, agent_card_json, created_at, updated_at)
333:     VALUES ($1, $2, $3, $4, $5)
334:     ON CONFLICT (name, organization) DO NOTHING
335: """, agent.name, agent.provider.organization,
336:     json.dumps(agent.model_dump()), datetime.utcnow(), datetime.utcnow())
337: 
338: # 查询同样使用占位符
339: await conn.fetchrow("""
340:     SELECT agent_card_json FROM agent_card
341:     WHERE name = $1 AND organization = $2
342: """, name, organization)
343: ```
344: 
345: ### 7.2 统一 SQL 语句管理
346: 
347: 为便于维护和审计，将 SQL 语句集中管理：
348: 
349: ```python
350: # agent_registry/persistence/sql_queries.py
351: """
352: SQL 语句集中管理 - 预编译模式
353: """
354: from enum import Enum
355: 
356: class PostgreSQLQueries(str, Enum):
357:     CREATE_AGENT = """
358:         INSERT INTO agent_card (name, organization, agent_card_json, created_at, updated_at)
359:         VALUES ($1, $2, $3, $4, $5)
360:         ON CONFLICT (name, organization) DO NOTHING
361:     """
362: 
363:     FIND_BY_KEY = """
364:         SELECT agent_card_json FROM agent_card
365:         WHERE name = $1 AND organization = $2
366:     """
367: 
368:     FIND_BY_NAME = """
369:         SELECT agent_card_json FROM agent_card WHERE name LIKE $1
370:     """
371: 
372:     FIND_BY_ORG = """
373:         SELECT agent_card_json FROM agent_card WHERE organization = $1
374:     """
375: 
376:     FIND_ALL = "SELECT agent_card_json FROM agent_card"
377: 
378:     UPDATE_AGENT = """
379:         UPDATE agent_card SET agent_card_json = $3, updated_at = $4
380:         WHERE name = $1 AND organization = $2
381:     """
382: 
383:     DELETE_AGENT = """
384:         DELETE FROM agent_card WHERE name = $1 AND organization = $2
385:     """
386: 
387:     COUNT = "SELECT COUNT(*) FROM agent_card"
388: ```
389: 
390: 存储实现中使用枚举引用 SQL：
391: 
392: ```python
393: # agent_registry/persistence/postgresql_storage.py
394: from .sql_queries import PostgreSQLQueries
395: 
396: class PostgreSQLStorage(StorageBackend):
397:     async def create(self, agent: AgentCard) -> bool:
398:         async with self.pool.acquire() as conn:
399:             await conn.execute(PostgreSQLQueries.CREATE_AGENT,
400:                 agent.name, agent.provider.organization,
401:                 json.dumps(agent.model_dump()), datetime.utcnow(), datetime.utcnow())
402:             ...
403: 
404:     async def find_by_key(self, name: str, organization: str) -> Optional[AgentCard]:
405:         async with self.pool.acquire() as conn:
406:             row = await conn.fetchrow(PostgreSQLQueries.FIND_BY_KEY, name, organization)
407:             ...
408: ```
409: 
410: ---
411: 
412: ## 8. 模块详细设计
413: 
414: ### 8.1 存储后端类图
415: 
416: ```mermaid
417: classDiagram
418:     class StorageBackend {
419:         <<abstract>>
420:         +init(config)$ StorageBackend
421:         +create(agent: AgentCard) bool
422:         +find_by_key(name, organization) AgentCard
423:         +find_by_name(name) List~AgentCard~
424:         +find_by_organization(org) List~AgentCard~
425:         +find_all() List~AgentCard~
426:         +update(name, org, data) bool
427:         +delete(name, organization) bool
428:         +count() int
429:         +close()
430:     }
431: 
432:     class StorageRegistry {
433:         +_backends: Dict
434:         +register(name, backend_class)
435:         +get_backend(mode, config) StorageBackend
436:     }
437: 
438:     class FileStorage {
439:         +init(config) FileStorage
440:         +create(agent) bool
441:         +find_by_key(name, org) AgentCard
442:         +find_by_name(name) List~AgentCard~
443:         +find_by_organization(org) List~AgentCard~
444:         +find_all() List~AgentCard~
445:         +update(name, org, data) bool
446:         +delete(name, org) bool
447:         +count() int
448:         +close()
449:     }
450: 
451:     class PostgreSQLStorage {
452:         -pool: asyncpg.Pool
453:         +init(config) PostgreSQLStorage
454:         +create(agent) bool
455:         +find_by_key(name, org) AgentCard
456:         +find_by_name(name) List~AgentCard~
457:         +find_by_organization(org) List~AgentCard~
458:         +find_all() List~AgentCard~
459:         +update(name, org, data) bool
460:         +delete(name, org) bool
461:         +count() int
462:         +close()
463:     }
464: 
465:     StorageBackend <|-- FileStorage
466:     StorageBackend <|-- PostgreSQLStorage
467:     StorageRegistry --> StorageBackend
468: ```
469: 
470: ### 8.1 存储后端抽象基类 `agent_registry/persistence/base.py`
471: 
472: ```python
473: """
474: 存储后端抽象基类
475: """
476: from abc import ABC, abstractmethod
477: from typing import List, Optional, Dict, Any
478: 
479: from a2a.types import AgentCard
480: 
481: class StorageBackend(ABC):
482:     """所有存储实现需继承此类"""
483: 
484:     @classmethod
485:     @abstractmethod
486:     async def init(cls, config: dict) -> 'StorageBackend':
487:         """初始化存储后端"""
488:         pass
489: 
490:     @abstractmethod
491:     async def create(self, agent: AgentCard) -> bool:
492:         """注册新Agent"""
493:         pass
494: 
495:     @abstractmethod
496:     async def find_by_key(self, name: str, organization: str) -> Optional[AgentCard]:
497:         """按 (name, organization) 查询"""
498:         pass
499: 
500:     @abstractmethod
501:     async def find_by_name(self, name: str) -> List[AgentCard]:
502:         """按 name 模糊查询"""
503:         pass
504: 
505:     @abstractmethod
506:     async def find_by_organization(self, organization: str) -> List[AgentCard]:
507:         """按 organization 精确查询"""
508:         pass
509: 
510:     @abstractmethod
511:     async def find_all(self) -> List[AgentCard]:
512:         """查询所有"""
513:         pass
514: 
515:     @abstractmethod
516:     async def update(self, name: str, organization: str, agent_data: Dict[str, Any]) -> bool:
517:         """更新Agent"""
518:         pass
519: 
520:     @abstractmethod
521:     async def delete(self, name: str, organization: str) -> bool:
522:         """删除Agent"""
523:         pass
524: 
525:     @abstractmethod
526:     async def count(self) -> int:
527:         """统计总数"""
528:         pass
529: 
530:     @abstractmethod
531:     async def close(self):
532:         """关闭连接"""
533:         pass
534: ```
535: 
536: ### 8.2 PostgreSQL 存储实现 `agent_registry/persistence/postgresql_storage.py`
537: 
538: ```python
539: """
540: Agent数据仓库
541: """
542: from typing import List, Optional, Dict, Any
543: from datetime import datetime
544: import json
545: import asyncpg
546: 
547: from a2a.types import AgentCard
548: from loguru import logger
549: from .base import StorageBackend
550: 
551: 
552: class PostgreSQLStorage(StorageBackend):
553:     """PostgreSQL 存储实现"""
554: 
555:     def __init__(self, pool: asyncpg.Pool):
556:         self.pool = pool
557: 
558:     @classmethod
559:     async def init(cls, config: dict) -> 'PostgreSQLStorage':
560:         pool = await asyncpg.create_pool(
561:             host=config['postgresql']['host'],
562:             port=config['postgresql']['port'],
563:             database=config['postgresql']['name'],
564:             user=config['postgresql']['username'],
565:             password=config['postgresql']['password'],
566:             min_size=config['postgresql'].get('pool', {}).get('min', 5),
567:             max_size=config['postgresql'].get('pool', {}).get('max', 20),
568:         )
569:         logger.info("PostgreSQL connection pool initialized")
570:         return cls(pool)
571: 
572:     async def create(self, agent: AgentCard) -> bool:
573:         async with self.pool.acquire() as conn:
574:             await conn.execute("""
575:                 INSERT INTO agent_card (name, organization, agent_card_json, created_at, updated_at)
576:                 VALUES ($1, $2, $3, $4, $5)
577:                 ON CONFLICT (name, organization) DO NOTHING
578:             """,
579:                 agent.name,
580:                 agent.provider.organization,
581:                 json.dumps(agent.model_dump()),
582:                 datetime.utcnow(),
583:                 datetime.utcnow()
584:             )
585:             return await self.find_by_key(agent.name, agent.provider.organization) is not None
586: 
587:     async def find_by_key(self, name: str, organization: str) -> Optional[AgentCard]:
588:         async with self.pool.acquire() as conn:
589:             row = await conn.fetchrow("""
590:                 SELECT agent_card_json FROM agent_card
591:                 WHERE name = $1 AND organization = $2
592:             """, name, organization)
593:             return AgentCard(**json.loads(row['agent_card_json'])) if row else None
594: 
595:     async def find_by_name(self, name: str) -> List[AgentCard]:
596:         async with self.pool.acquire() as conn:
597:             rows = await conn.fetch("""
598:                 SELECT agent_card_json FROM agent_card WHERE name LIKE $1
599:             """, f"%{name}%")
600:             return [AgentCard(**json.loads(r['agent_card_json'])) for r in rows]
601: 
602:     async def find_by_organization(self, organization: str) -> List[AgentCard]:
603:         async with self.pool.acquire() as conn:
604:             rows = await conn.fetch("""
605:                 SELECT agent_card_json FROM agent_card WHERE organization = $1
606:             """, organization)
607:             return [AgentCard(**json.loads(r['agent_card_json'])) for r in rows]
608: 
609:     async def find_all(self) -> List[AgentCard]:
610:         async with self.pool.acquire() as conn:
611:             rows = await conn.fetch("SELECT agent_card_json FROM agent_card")
612:             return [AgentCard(**json.loads(r['agent_card_json'])) for r in rows]
613: 
614:     async def update(self, name: str, organization: str, agent_data: Dict[str, Any]) -> bool:
615:         async with self.pool.acquire() as conn:
616:             agent = AgentCard(**agent_data)
617:             result = await conn.execute("""
618:                 UPDATE agent_card SET agent_card_json = $3, updated_at = $4
619:                 WHERE name = $1 AND organization = $2
620:             """, name, organization, json.dumps(agent.model_dump()), datetime.utcnow())
621:             return result != "UPDATE 0"
622: 
623:     async def delete(self, name: str, organization: str) -> bool:
624:         async with self.pool.acquire() as conn:
625:             result = await conn.execute("""
626:                 DELETE FROM agent_card WHERE name = $1 AND organization = $2
627:             """, name, organization)
628:             return result != "DELETE 0"
629: 
630:     async def count(self) -> int:
631:         async with self.pool.acquire() as conn:
632:             return await conn.fetchval("SELECT COUNT(*) FROM agent_card")
633: 
634:     async def close(self):
635:         if self.pool:
636:             await self.pool.close()
637:             logger.info("PostgreSQL connection pool closed")
638: ```
639: 
640: ### 8.3 后续扩展说明
641: 
642: 后续可按需扩展 SQLite、GaussDB 等存储实现，只需：
643: 
644: 1. 实现 `StorageBackend` 抽象基类
645: 2. 在 `StorageRegistry` 中注册
646: 
647: **SQLite 扩展示例**（不在本次交付范围内）：
648: 
649: ```python
650: # agent_registry/persistence/sqlite_storage.py
651: import aiosqlite
652: 
653: class SQLiteStorage(StorageBackend):
654:     @classmethod
655:     async def init(cls, config: dict) -> 'SQLiteStorage':
656:         db_path = config.get('sqlite', {}).get('path', 'data/agents.db')
657:         instance = cls(db_path)
658:         instance.conn = await aiosqlite.connect(db_path)
659:         return instance
660: 
661:     async def create(self, agent: AgentCard) -> bool:
662:         await self.conn.execute("""
663:             INSERT OR IGNORE INTO agent_card (name, organization, agent_card_json)
664:             VALUES (?, ?, ?)
665:         """, (agent.name, agent.provider.organization, json.dumps(agent.model_dump())))
666:         await self.conn.commit()
667:         return True
668:     # ... 实现其他方法，使用 ? 占位符
669: ```
670: 
671: **GaussDB 扩展示例**（不在本次交付范围内）：
672: 
673: ```python
674: # agent_registry/persistence/gauss_storage.py
675: from gaussdb import create_pool  # 华为 GaussDB Python 驱动
676: 
677: class GaussDBStorage(StorageBackend):
678:     @classmethod
679:     async def init(cls, config: dict) -> 'GaussDBStorage':
680:         pool = await create_pool(
681:             host=config['gauss']['host'],
682:             port=config['gauss']['port'],
683:             database=config['gauss']['database'],
684:             user=config['gauss']['username'],
685:             password=config['gauss']['password'],
686:         )
687:         return cls(pool)
688:     # ... 使用 $1, $2 占位符，类似 PostgreSQL
689: ```
690: 
691: ---
692: 
693: ## 9. 核心代码改动
694: 
695: ### 9.1 持久化配置加载
696: 
697: ```python
698: # agent_registry/config.py
699: PERSISTENCE_CONF = get_persistence_conf()
700: PERSISTENCE_MODE = PERSISTENCE_CONF.get("persistence.mode", "file")  # file / postgresql
701: ```
702: 
703: ### 9.2 存储实现注册机制
704: 
705: ```python
706: # agent_registry/persistence/__init__.py
707: """
708: 存储实现注册表 - 根据配置动态加载对应存储实现
709: """
710: from abc import ABC, abstractmethod
711: from typing import List, Optional, Dict, Any
712: from loguru import logger
713: 
714: class StorageBackend(ABC):
715:     """存储后端抽象接口"""
716:     @abstractmethod
717:     async def create(self, agent: AgentCard) -> bool: ...
718:     @abstractmethod
719:     async def find_by_key(self, name: str, organization: str) -> Optional[AgentCard]: ...
720:     @abstractmethod
721:     async def find_by_name(self, name: str) -> List[AgentCard]: ...
722:     @abstractmethod
723:     async def find_by_organization(self, organization: str) -> List[AgentCard]: ...
724:     @abstractmethod
725:     async def find_all(self) -> List[AgentCard]: ...
726:     @abstractmethod
727:     async def update(self, name: str, organization: str, agent_data: Dict[str, Any]) -> bool: ...
728:     @abstractmethod
729:     async def delete(self, name: str, organization: str) -> bool: ...
730:     @abstractmethod
731:     async def count(self) -> int: ...
732: 
733: class StorageRegistry:
734:     """存储实现注册表"""
735:     _backends: Dict[str, type] = {}
736: 
737:     @classmethod
738:     def register(cls, name: str, backend_class: type):
739:         cls._backends[name] = backend_class
740: 
741:     @classmethod
742:     async def get_backend(cls, mode: str, config: dict) -> StorageBackend:
743:         if mode not in cls._backends:
744:             raise ValueError(f"Unknown storage mode: {mode}")
745:         backend = cls._backends[mode]
746:         return await backend.init(config)
747: 
748: # 注册各存储实现
749: from .file_storage import FileStorage
750: from .postgresql_storage import PostgreSQLStorage
751: 
752: StorageRegistry.register("file", FileStorage)
753: StorageRegistry.register("postgresql", PostgreSQLStorage)
754: 
755: # 后续可扩展 SQLite、GaussDB 等
756: # StorageRegistry.register("sqlite", SQLiteStorage)
757: # StorageRegistry.register("gauss", GaussDBStorage)
758: ```
759: 
760: ### 9.3 `agent_registry/core.py` 使用示例
761: 
762: **启动时序图**：
763: 
764: ```mermaid
765: sequenceDiagram
766:     participant Client
767:     participant Core as RegistryCore
768:     participant Reg as StorageRegistry
769:     participant Storage as StorageBackend
770:     participant DB as PostgreSQL
771: 
772:     Note over Core: 1. 读取配置 get_persistence_conf()
773:     Core->>Reg: get_backend(mode, config)
774:     
775:     Reg->>Storage: init(config)
776:     
777:     alt mode == "file"
778:         Storage->>Storage: FileStorage.init()
779:     else mode == "postgresql"
780:         Storage->>DB: asyncpg.create_pool()
781:         DB-->>Storage: pool
782:         Storage-->>Core: PostgreSQLStorage instance
783:     end
784:     
785:     Core-->>Client: 初始化完成
786:     
787:     Note over Client,DB: 运行时: Agent 注册流程
788:     Client->>Core: register(agent)
789:     Core->>Storage: create(agent)
790:     Storage->>DB: INSERT with $1,$2,$3 (预编译)
791:     DB-->>Storage: result
792:     Storage-->>Client: success
793: ```
794: 
795: ```python
796: # agent_registry/core.py
797: 
798: class RegistryCore:
799:     def __init__(self, config: dict = None):
800:         self.config = config or PERSISTENCE_CONF
801:         self.mode = self.config.get("persistence.mode", "file")
802:         self.storage: StorageBackend = None
803: 
804:     async def initialize(self):
805:         """初始化存储后端"""
806:         self.storage = await StorageRegistry.get_backend(
807:             self.mode,
808:             self.config
809:         )
810:         logger.info(f"Registry initialized with {self.mode} storage")
811: 
812:     async def register(self, agent: AgentCard) -> bool:
813:         return await self.storage.create(agent)
814: 
815:     async def find_exact(self, name: Optional[str] = None,
816:                         organization: Optional[str] = None) -> List[AgentCard]:
817:         if name and organization:
818:             result = await self.storage.find_by_key(name, organization)
819:             return [result] if result else []
820:         elif name:
821:             return await self.storage.find_by_name(name)
822:         elif organization:
823:             return await self.storage.find_by_organization(organization)
824:         return await self.storage.find_all()
825: ```
826: 
827: ---
828: 
829: ## 10. 启动流程
830: 
831: ```python
832: # agent_registry/start.py
833: 
834: async def main():
835:     # 初始化配置
836:     mode = PERSISTENCE_CONF.get("persistence.mode", "file")
837: 
838:     # 根据配置动态初始化存储后端
839:     registry = RegistryCore(PERSISTENCE_CONF)
840:     await registry.initialize()
841: 
842:     # 注册关闭时清理资源
843:     atexit.register(lambda: asyncio.create_task(registry.storage.close()))
844: 
845:     # 启动服务
846:     ...
847: ```
848: 
849: ---
850: 
851: ## 11. 测试设计
852: 
853: | 测试用例 | 描述 |
854: |---------|------|
855: | test_file_storage | 文件存储 CRUD |
856: | test_postgresql_storage | PostgreSQL 存储 CRUD |
857: | test_storage_registry | 动态加载存储实现 |
858: | test_concurrent_register | 多实例并发注册 |
859: 
860: ---
861: 
862: ## 12. 文件清单
863: 
864: ### 新增文件
865: 
866: | 文件路径 | 说明 |
867: |---------|------|
868: | `etc/conf/persistence.conf` | 持久化配置模板 |
869: | `agent_registry/persistence/__init__.py` | 存储注册表 |
870: | `agent_registry/persistence/base.py` | 存储后端抽象基类 |
871: | `agent_registry/persistence/sql_queries.py` | SQL 语句集中管理 |
872: | `agent_registry/persistence/file_storage.py` | 文件存储实现 |
873: | `agent_registry/persistence/postgresql_storage.py` | PostgreSQL 存储实现 |
874: 
875: ### 修改文件
876: 
877: | 文件 | 改动 |
878: |------|------|
879: | `common/util/conf_util.py` | 新增 `get_persistence_conf()`，解密数据库口令 |
880: | `common/util/cipher_util.py` | 完善 `encrypt()`/`decrypt()` 实现 |
881: | `agent_registry/init.py` | 添加持久化配置方法 `config_persistence()`（最后一步） |
882: | `agent_registry/config.py` | 新增 PERSISTENCE_CONF |
883: | `agent_registry/core.py` | 使用 StorageRegistry |
884: | `agent_registry/start.py` | 动态初始化存储后端 |
885: 
886: ---
887: 
888: ## 13. 实现计划
889: 
890: | 阶段 | 内容 |
891: |------|------|
892: | 1 | 新增持久化配置解析模块 `get_persistence_conf()` |
893: | 2 | 完善加密工具 `cipher_util.py` 的 `encrypt()`/`decrypt()` |
894: | 3 | 扩展 `init.py` 添加持久化配置方法 `config_persistence()` |
895: | 4 | 实现存储后端抽象基类 `base.py` |
896: | 5 | 实现 SQL 语句集中管理 `sql_queries.py` |
897: | 6 | 实现文件存储 `file_storage.py` |
898: | 7 | 实现 PostgreSQL 存储 `postgresql_storage.py` |
899: | 8 | 实现存储注册表 `__init__.py` |
900: | 9 | 修改 `core.py` 使用 StorageRegistry |
901: | 10 | 单元测试 |

(End of file - total 901 lines)
</content>
```

---

## Assistant (Build · GLM-5 · 181.9s)

_Thinking:_

现在我对项目有了全面的理解。让我编写设计文档，基于现有的架构设计owner隔离功能。

关键要点：
1. 现有系统使用证书验证（在common/cert目录）
2. 证书解析时可以获取subject信息（CN字段在subject中）
3. 存储有两种模式：file模式和postgresql模式
4. 需要新增owner字段到agent数据中

让我编写设计文档。

基于项目现有架构，我来编写owner隔离的设计文档：

**Tool: write**

**Input:**
```json
{
  "filePath": "C:\\Users\\c30028839\\Desktop\\code\\A2A\\agent-registry_v1\\owner-isolation-design.md",
  "content": "# Agent注册中心 Owner隔离方案设计\n\n## 0. 体系架构图\n\n```mermaid\ngraph TB\n    subgraph Client\n        A[Agent Client<br/>携带TLS客户端证书]\n    end\n\n    subgraph \"Agent Registry\"\n        M[\"TLS Middleware<br/>证书解析\"]\n        R[\"RegistryCore<br/>注册核心\"]\n        S[\"StorageRegistry<br/>存储注册表\"]\n        \n        subgraph StorageBackends\n            F[\"FileStorage<br/>按owner分文件存储\"]\n            P[\"PostgreSQLStorage<br/>owner字段隔离\"]\n        end\n    end\n\n    subgraph Database\n        DB[(PostgreSQL<br/>owner字段索引)]\n    end\n\n    A -->|TLS握手+客户端证书| M\n    M -->|解析CN作为owner| R\n    R -->|存储时携带owner| S\n    S -->|file模式| F\n    S -->|postgresql模式| P\n    P -->|owner字段| DB\n```\n\n---\n\n## 1. 设计目标\n\n### 1.1 核心需求\n\n| 需求 | 描述 |\n|------|------|\n| 注册隔离 | 从TLS客户端证书提取CN作为owner，入库保存 |\n| 操作鉴权 | 删除/修改时校验证书CN与库中owner匹配 |\n| 多存储模式 | 文件模式和数据库模式均支持owner隔离 |\n\n### 1.2 Owner定义\n\n**Owner来源**: TLS客户端证书的 `Subject CN (Common Name)` 字段\n\n证书Subject示例：\n```\nCN=agent-admin-001,OU=AgentOps,O=Huawei,L=Shenzhen,C=CN\n```\n\n提取逻辑：从 `subject` 字符串解析 `CN=xxx` 的值。\n\n---\n\n## 2. 数据模型变更\n\n### 2.1 AgentCard扩展字段\n\n由于AgentCard是protobuf定义的外部模型，建议采用**扩展存储**方式：\n\n```python\n# 存储时附加owner元数据\nagent_record = {\n    \"agent_card\": MessageToDict(agent, preserving_proto_field_name=True),\n    \"owner\": \"agent-admin-001\",  # 新增字段\n    \"created_at\": datetime.utcnow(),\n    \"updated_at\": datetime.utcnow()\n}\n```\n\n### 2.2 PostgreSQL表结构变更\n\n```sql\n-- 新增owner字段和索引\nALTER TABLE agent_card ADD COLUMN owner VARCHAR(100) NOT NULL DEFAULT 'system';\n\n-- 复合唯一键：name + organization + owner\n-- 允许同一agent被多个owner注册（视业务需求而定）\n-- 方案A：全局唯一，一个agent只能被一个owner注册\nDROP INDEX IF EXISTS agent_card_name_org_key;\nCREATE UNIQUE INDEX idx_agent_unique ON agent_card(name, organization);\n\n-- 方案B：owner隔离，同一agent可被不同owner分别注册\nCREATE UNIQUE INDEX idx_agent_owner_unique ON agent_card(name, organization, owner);\n\n-- owner查询索引\nCREATE INDEX idx_agent_owner ON agent_card(owner);\n```\n\n**推荐方案A**：全局唯一，简化管理，owner仅用于权限校验。\n\n---\n\n## 3. 证书CN解析设计\n\n### 3.1 CN提取工具\n\n新增 `common/cert/cert_cn_parser.py`：\n\n```python\n\"\"\"\n从X509证书Subject中提取CN字段\n\"\"\"\nimport re\nfrom typing import Optional\n\nfrom common.cert.x509_obj import CertObj\n\n\ndef extract_cn_from_subject(subject: str) -> Optional[str]:\n    \"\"\"\n    从证书Subject字符串中提取CN值\n    \n    Subject格式: CN=xxx,OU=yyy,O=zzz...\n    支持多种格式:\n    - CN=agent-admin-001,OU=...\n    - CN=agent admin 001,OU=...  (带空格)\n    \n    Args:\n        subject: RFC4514格式的Subject字符串\n        \n    Returns:\n        CN值，若不存在返回None\n    \"\"\"\n    if not subject:\n        return None\n    \n    # RFC4514格式: 属性=值,属性=值\n    # CN可能在任意位置，需要解析整个字符串\n    pattern = r'CN=([^,]+)'\n    match = re.search(pattern, subject)\n    if match:\n        cn_value = match.group(1).strip()\n        # 处理特殊字符转义（RFC4514中逗号用\\,转义）\n        cn_value = cn_value.replace('\\\\,', ',')\n        return cn_value\n    \n    return None\n\n\ndef extract_cn_from_cert(cert_obj: CertObj) -> Optional[str]:\n    \"\"\"\n    从CertObj对象提取CN\n    \n    Args:\n        cert_obj: CertObj实例\n        \n    Returns:\n        CN值\n    \"\"\"\n    return extract_cn_from_subject(cert_obj.subject)\n\n\ndef validate_cn(cn: str) -> bool:\n    \"\"\"\n    校验CN是否合法\n    \n    规则:\n    - 长度: 1-100字符\n    - 允许字符: 字母、数字、下划线、连字符、点、空格\n    - 禁止: 特殊符号、控制字符\n    \n    Args:\n        cn: CN值\n        \n    Returns:\n        是否合法\n    \"\"\"\n    if not cn or len(cn) > 100:\n        return False\n    \n    # 允许的字符集\n    import string\n    allowed_chars = string.ascii_letters + string.digits + '_-. '\n    \n    return all(c in allowed_chars for c in cn)\n```\n\n### 3.2 证书解析集成\n\n修改 `common/cert/cert_parser.py`，在 `_extract_certificate_info` 中增加CN提取：\n\n```python\ndef _extract_certificate_info(cert: x509.Certificate) -> CertObj:\n    \"\"\"从cryptography证书对象中提取信息\"\"\"\n    info = {\n        'subject': cert.subject.rfc4514_string(),\n        'issuer': cert.issuer.rfc4514_string(),\n        'serial_number': hex(cert.serial_number),\n        'valid_from': cert.not_valid_before_utc.isoformat(),\n        'valid_to': cert.not_valid_after_utc.isoformat(),\n        'version': cert.version,\n        'public_key': cert.public_key(),\n        'org_cert': cert,\n        'cn': extract_cn_from_subject(cert.subject.rfc4514_string())  # 新增\n    }\n    obj = CertObj.from_dict(info)\n    return obj\n```\n\n修改 `common/cert/x509_obj.py`：\n\n```python\nclass CertObj:\n    subject = None\n    issuer = None\n    serial_number = None\n    valid_from = None\n    valid_to = None\n    version = None\n    public_key = None\n    org_cert = None\n    cn = None  # 新增\n\n    @classmethod\n    def from_dict(cls, cert_dict):\n        obj = cls()\n        obj.subject = cert_dict.get('subject', '')\n        obj.issuer = cert_dict.get('issuer', '')\n        obj.serial_number = cert_dict.get('serial_number', '')\n        obj.valid_from = cert_dict.get('valid_from', '')\n        obj.valid_to = cert_dict.get('valid_to', '')\n        obj.version = cert_dict.get('version', '')\n        obj.public_key = cert_dict.get('public_key', None)\n        obj.org_cert = cert_dict.get('org_cert', None)\n        obj.cn = cert_dict.get('cn', None)  # 新增\n        return obj\n```\n\n---\n\n## 4. REST接口改造设计\n\n### 4.1 接口改造总览\n\n| 接口 | 改造内容 |\n|------|---------|\n| POST /register | 从证书提取CN作为owner入库 |\n| PUT /update | 校验证书CN与agent owner匹配 |\n| DELETE /deregister | 校验证书CN与agent owner匹配 |\n| GET /query | 无变更（可选：按owner过滤） |\n| GET /retrieve | 无变更（可选：按owner过滤） |\n\n### 4.2 证书获取方式\n\n**方案选择**：通过TLS握手获取客户端证书\n\nFastAPI中获取客户端证书：\n\n```python\n# 方案A：通过SSL context获取（推荐）\n# 需要配置uvicorn SSL参数\nssl_context = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)\nssl_context.load_cert_chain(server_cert, server_key)\nssl_context.load_verify_locations(ca_cert)\nssl_context.verify_mode = ssl.CERT_REQUIRED  # 强制客户端证书\n\n# 启动命令\nuvicorn.run(app, ssl=ssl_context)\n\n# 接口中获取证书\n@app.post(\"/register\")\nasync def register_agent(request: Request):\n    # 从request.scope获取SSL信息\n    ssl_info = request.scope.get('ssl', {})\n    # 或从transport获取\n    transport = request.scope.get('transport')\n    # 具体获取方式依赖服务器配置\n```\n\n**方案B：通过HTTP Header传递（代理场景）**\n\n当Agent Registry部署在反向代理后（如Nginx），由代理解析证书并传递：\n\n```nginx\n# Nginx配置\nssl_client_certificate /path/to/ca.crt;\nssl_verify_client on;\n\n# 传递CN到后端\nproxy_set_header X-SSL-Client-CN $ssl_client_s_dn_cn;\n```\n\n```python\n# FastAPI获取\n@app.post(\"/register\")\nasync def register_agent(request: Request):\n    owner = request.headers.get('X-SSL-Client-CN')\n    if not owner:\n        raise HTTPException(status_code=401, detail=\"Client certificate required\")\n```\n\n**推荐方案B**：更灵活，支持代理场景。\n\n### 4.3 注册接口改造\n\n```python\n@app.post(\"/rest/a2a-t/v1/agents/register\")\nasync def register_agent(request: Request):\n    \"\"\"注册Agent，从证书提取owner\"\"\"\n    \n    # 1. 获取owner（从Header或SSL）\n    owner = request.headers.get('X-SSL-Client-CN')\n    if not owner:\n        raise HTTPException(\n            status_code=status.HTTP_401_UNAUTHORIZED,\n            detail=\"Client certificate CN required\"\n        )\n    \n    # 2. 校验CN格式\n    from common.cert.cert_cn_parser import validate_cn\n    if not validate_cn(owner):\n        raise HTTPException(\n            status_code=status.HTTP_400_BAD_REQUEST,\n            detail=f\"Invalid CN format: {owner}\"\n        )\n    \n    # 3. 解析AgentCard\n    body = await request.body()\n    agent = Parse(body, AgentCard())\n    \n    # 4. 注册（携带owner）\n    save_handle = HandlerRegistry.get_handler(InterfaceType.INSERT)\n    success = await save_handle.handle(agent, owner=owner)\n    \n    return JSONResponse(content=success, status_code=status.HTTP_201_CREATED)\n```\n\n### 4.4 更新/删除接口改造\n\n```python\nasync def _verify_owner_permission(\n    request: Request, \n    name: str, \n    organization: str\n) -> str:\n    \"\"\"\n    校验owner权限\n    \n    流程:\n    1. 从证书获取CN作为current_owner\n    2. 查询agent获取stored_owner\n    3. 比对是否匹配\n    \n    Returns:\n        current_owner (校验成功)\n        \n    Raises:\n        HTTPException: 证书缺失、权限不匹配\n    \"\"\"\n    # 1. 获取当前证书CN\n    current_owner = request.headers.get('X-SSL-Client-CN')\n    if not current_owner:\n        raise HTTPException(\n            status_code=status.HTTP_401_UNAUTHORIZED,\n            detail=\"Client certificate required\"\n        )\n    \n    # 2. 查询agent\n    query_handle = HandlerRegistry.get_handler(InterfaceType.GET)\n    agent = await query_handle.handle(name, organization)\n    if not agent:\n        raise HTTPException(\n            status_code=status.HTTP_404_NOT_FOUND,\n            detail=f\"Agent ({name}, {organization}) not found\"\n        )\n    \n    # 3. 获取存储的owner\n    stored_owner = agent.get('owner', 'system')  # 兼容旧数据\n    \n    # 4. 权限校验\n    if current_owner != stored_owner:\n        raise HTTPException(\n            status_code=status.HTTP_403_FORBIDDEN,\n            detail=f\"Permission denied: agent belongs to {stored_owner}\"\n        )\n    \n    return current_owner\n\n\n@app.put(\"/rest/a2a-t/v1/update_agent/{name}\")\nasync def update_agent(request: Request, name: str, organization: str):\n    \"\"\"更新Agent，校验owner权限\"\"\"\n    \n    # 1. 权限校验\n    owner = await _verify_owner_permission(request, name, organization)\n    \n    # 2. 执行更新\n    body = await request.body()\n    agent_data = Parse(body, AgentCard())\n    \n    update_handle = HandlerRegistry.get_handler(InterfaceType.UPDATE)\n    success = await update_handle.handle(name, organization, agent_data, owner=owner)\n    \n    return success\n\n\n@app.delete(\"/rest/a2a-t/v1/deregister_agent/{name}\")\nasync def deregister_agent(request: Request, name: str, organization: str):\n    \"\"\"注销Agent，校验owner权限\"\"\"\n    \n    # 1. 权限校验\n    owner = await _verify_owner_permission(request, name, organization)\n    \n    # 2. 执行删除\n    deregister_handle = HandlerRegistry.get_handler(InterfaceType.DEREGISTER)\n    success = await deregister_handle.handle(name, organization, owner=owner)\n    \n    return success\n```\n\n---\n\n## 5. 存储层改造设计\n\n### 5.1 StorageBackend接口扩展\n\n```python\n# agent_registry/persistence/base.py\nclass StorageBackend(ABC):\n    @abstractmethod\n    def create(self, agent: AgentCard, owner: str) -> bool:\n        \"\"\"注册Agent，携带owner\"\"\"\n        pass\n    \n    @abstractmethod\n    def find_by_key(self, name: str, organization: str) -> Optional[Dict]:\n        \"\"\"查询Agent，返回包含owner的完整记录\"\"\"\n        pass\n    \n    @abstractmethod\n    def find_by_owner(self, owner: str) -> List[AgentCard]:\n        \"\"\"按owner查询（新增）\"\"\"\n        pass\n    \n    @abstractmethod\n    def update(self, name: str, organization: str, agent_data: Dict, owner: str) -> bool:\n        \"\"\"更新Agent，携带owner校验\"\"\"\n        pass\n    \n    @abstractmethod\n    def delete(self, name: str, organization: str, owner: str) -> bool:\n        \"\"\"删除Agent，携带owner校验\"\"\"\n        pass\n```\n\n### 5.2 PostgreSQL存储改造\n\n```python\n# agent_registry/persistence/sql_queries.py 新增\nclass PostgreSQLQueries(str, Enum):\n    # ... 现有语句 ...\n    \n    # 新增owner相关\n    CREATE_AGENT_WITH_OWNER = \"\"\"\n        INSERT INTO agent_card (name, organization, owner, agent_card_json, created_at, updated_at)\n        VALUES ($1, $2, $3, $4, $5, $6)\n        ON CONFLICT (name, organization) DO NOTHING\n    \"\"\"\n    \n    FIND_BY_OWNER = \"\"\"\n        SELECT agent_card_json, owner FROM agent_card WHERE owner = $1\n    \"\"\"\n    \n    UPDATE_AGENT_WITH_OWNER_CHECK = \"\"\"\n        UPDATE agent_card \n        SET agent_card_json = $3, updated_at = $4\n        WHERE name = $1 AND organization = $2 AND owner = $5\n    \"\"\"\n    \n    DELETE_AGENT_WITH_OWNER_CHECK = \"\"\"\n        DELETE FROM agent_card \n        WHERE name = $1 AND organization = $2 AND owner = $3\n    \"\"\"\n```\n\n```python\n# agent_registry/persistence/postgresql_storage.py 改造\nclass PostgreSQLStorage(StorageBackend):\n    \n    def create(self, agent: AgentCard, owner: str) -> bool:\n        conn = self.pool.getconn()\n        try:\n            with conn.cursor() as cur:\n                agent_dict = MessageToDict(agent, preserving_proto_field_name=True)\n                now = datetime.utcnow()\n                cur.execute(\n                    PostgreSQLQueries.CREATE_AGENT_WITH_OWNER.value,\n                    (agent.name, agent.provider.organization, owner, \n                     json.dumps(agent_dict), now, now)\n                )\n                conn.commit()\n            return cur.rowcount > 0\n        finally:\n            self.pool.putconn(conn)\n    \n    def find_by_key(self, name: str, organization: str) -> Optional[Dict]:\n        \"\"\"返回包含owner的完整记录\"\"\"\n        conn = self.pool.getconn()\n        try:\n            with conn.cursor() as cur:\n                cur.execute(\n                    PostgreSQLQueries.FIND_BY_KEY.value,\n                    (name, organization)\n                )\n                row = cur.fetchone()\n            if row:\n                data = row[0] if isinstance(row[0], dict) else json.loads(row[0])\n                owner = row[1] if len(row) > 1 else 'system'\n                return {\"agent_card\": AgentCard(**data), \"owner\": owner}\n            return None\n        finally:\n            self.pool.putconn(conn)\n    \n    def update(self, name: str, organization: str, agent_data: Dict, owner: str) -> bool:\n        conn = self.pool.getconn()\n        try:\n            with conn.cursor() as cur:\n                now = datetime.utcnow()\n                cur.execute(\n                    PostgreSQLQueries.UPDATE_AGENT_WITH_OWNER_CHECK.value,\n                    (name, organization, json.dumps(agent_data), now, owner)\n                )\n                conn.commit()\n                affected = cur.rowcount\n            return affected > 0\n        finally:\n            self.pool.putconn(conn)\n    \n    def delete(self, name: str, organization: str, owner: str) -> bool:\n        conn = self.pool.getconn()\n        try:\n            with conn.cursor() as cur:\n                cur.execute(\n                    PostgreSQLQueries.DELETE_AGENT_WITH_OWNER_CHECK.value,\n                    (name, organization, owner)\n                )\n                conn.commit()\n                affected = cur.rowcount\n            return affected > 0\n        finally:\n            self.pool.putconn(conn)\n```\n\n### 5.3 文件存储改造（推荐方案）\n\n#### 方案A：单文件存储 + owner元数据\n\n**结构**：单个JSON文件，每条记录携带owner字段\n\n```json\n// data/agents.json\n[\n    {\n        \"name\": \"agent-001\",\n        \"organization\": \"org-A\",\n        \"owner\": \"admin-001\",\n        \"agent_card\": {...},\n        \"created_at\": \"2026-01-01T00:00:00Z\"\n    },\n    {\n        \"name\": \"agent-002\",\n        \"organization\": \"org-B\",\n        \"owner\": \"admin-002\",\n        \"agent_card\": {...}\n    }\n]\n```\n\n**优点**：\n- 实现简单，改动小\n- 跨owner查询方便\n- 数据迁移平滑\n\n**缺点**：\n- 大文件性能问题（已有max_file_size限制）\n- 无物理隔离\n\n```python\n# agent_registry/persistence/file_storage.py 改造\nclass FileStorage(StorageBackend):\n    \n    def create(self, agent: AgentCard, owner: str) -> bool:\n        key = (agent.name.strip(), agent.provider.organization.strip())\n        agent_dict = MessageToDict(agent, preserving_proto_field_name=True)\n        \n        # 存储结构：包含owner元数据\n        record = {\n            \"name\": agent.name,\n            \"organization\": agent.provider.organization,\n            \"owner\": owner,\n            \"agent_card\": agent_dict,\n            \"created_at\": datetime.utcnow().isoformat(),\n            \"updated_at\": datetime.utcnow().isoformat()\n        }\n        \n        self._agents[key] = record\n        self._save()\n        return True\n    \n    def find_by_key(self, name: str, organization: str) -> Optional[Dict]:\n        key = (name.strip(), organization.strip())\n        record = self._agents.get(key)\n        if record:\n            return {\n                \"agent_card\": AgentCard(**record[\"agent_card\"]),\n                \"owner\": record.get(\"owner\", \"system\")\n            }\n        return None\n    \n    def update(self, name: str, organization: str, agent_data: Dict, owner: str) -> bool:\n        key = (name.strip(), organization.strip())\n        record = self._agents.get(key)\n        if not record:\n            return False\n        \n        # 校验owner\n        if record.get(\"owner\", \"system\") != owner:\n            raise PermissionError(f\"Agent belongs to {record['owner']}\")\n        \n        record[\"agent_card\"] = agent_data\n        record[\"updated_at\"] = datetime.utcnow().isoformat()\n        self._agents[key] = record\n        self._save()\n        return True\n    \n    def delete(self, name: str, organization: str, owner: str) -> bool:\n        key = (name.strip(), organization.strip())\n        record = self._agents.get(key)\n        if not record:\n            return False\n        \n        # 校验owner\n        if record.get(\"owner\", \"system\") != owner:\n            raise PermissionError(f\"Agent belongs to {record['owner']}\")\n        \n        del self._agents[key]\n        self._save()\n        return True\n    \n    def _save(self) -> None:\n        # 保存完整记录（包含owner）\n        records = []\n        for record in self._agents.values():\n            records.append(record)\n        \n        json_str = json.dumps(records, ensure_ascii=False, indent=2)\n        # ... 大小检查和写入逻辑 ...\n```\n\n#### 方案B：按owner分目录存储（物理隔离）\n\n**目录结构**：\n```\ndata/\n├── agents/                     # 主索引（可选）\n│   └── index.json              # name->owner映射\n├── owner_admin-001/            # owner专属目录\n│   ├── agent-001_org-A.json\n│   └── agent-003_org-C.json\n├── owner_admin-002/\n│   ├── agent-002_org-B.json\n│   └── ...\n└── owner_system/               # 系统级agent\n    └── default_agent.json\n```\n\n**优点**：\n- 物理隔离，权限边界清晰\n- 单owner数据量可控\n- 便于备份/迁移特定owner数据\n\n**缺点**：\n- 实现复杂\n- 跨owner查询需遍历目录\n- 数据迁移需重构\n\n```python\n# agent_registry/persistence/file_storage_owner_split.py\n\"\"\"\n按owner分目录存储实现\n\"\"\"\nimport os\nfrom pathlib import Path\nfrom typing import Dict, Optional\n\nclass OwnerSplitFileStorage(StorageBackend):\n    \n    def __init__(self, data_dir: str = \"data/agents\"):\n        self.data_dir = Path(data_dir)\n        self.data_dir.mkdir(parents=True, exist_ok=True)\n        self._index: Dict[tuple, str] = {}  # (name, org) -> owner\n        self._load_index()\n    \n    def _get_owner_dir(self, owner: str) -> Path:\n        \"\"\"获取owner专属目录\"\"\"\n        owner_dir = self.data_dir / f\"owner_{owner}\"\n        owner_dir.mkdir(exist_ok=True)\n        # 设置目录权限（仅owner可访问）\n        os.chmod(owner_dir, 0o700)\n        return owner_dir\n    \n    def _get_agent_file(self, owner: str, name: str, org: str) -> Path:\n        \"\"\"获取agent存储文件路径\"\"\"\n        owner_dir = self._get_owner_dir(owner)\n        # 文件名：name_org.json（处理特殊字符）\n        safe_name = name.replace('/', '_').replace('\\\\', '_')\n        safe_org = org.replace('/', '_').replace('\\\\', '_')\n        return owner_dir / f\"{safe_name}_{safe_org}.json\"\n    \n    def create(self, agent: AgentCard, owner: str) -> bool:\n        key = (agent.name.strip(), agent.provider.organization.strip())\n        \n        # 检查是否已存在\n        if key in self._index:\n            return False\n        \n        # 存储agent文件\n        agent_file = self._get_agent_file(owner, agent.name, agent.provider.organization)\n        agent_dict = MessageToDict(agent, preserving_proto_field_name=True)\n        \n        record = {\n            \"agent_card\": agent_dict,\n            \"owner\": owner,\n            \"created_at\": datetime.utcnow().isoformat()\n        }\n        \n        with open(agent_file, 'w', encoding='utf-8') as f:\n            json.dump(record, f, ensure_ascii=False, indent=2)\n        os.chmod(agent_file, 0o600)\n        \n        # 更新索引\n        self._index[key] = owner\n        self._save_index()\n        \n        return True\n    \n    def find_by_key(self, name: str, organization: str) -> Optional[Dict]:\n        key = (name.strip(), organization.strip())\n        owner = self._index.get(key)\n        \n        if not owner:\n            return None\n        \n        agent_file = self._get_agent_file(owner, name, organization)\n        if not agent_file.exists():\n            return None\n        \n        with open(agent_file, 'r', encoding='utf-8') as f:\n            record = json.load(f)\n        \n        return {\n            \"agent_card\": AgentCard(**record[\"agent_card\"]),\n            \"owner\": record[\"owner\"]\n        }\n    \n    def update(self, name: str, organization: str, agent_data: Dict, owner: str) -> bool:\n        key = (name.strip(), organization.strip())\n        stored_owner = self._index.get(key)\n        \n        if not stored_owner:\n            return False\n        \n        if stored_owner != owner:\n            raise PermissionError(f\"Agent belongs to {stored_owner}\")\n        \n        agent_file = self._get_agent_file(owner, name, organization)\n        \n        record = {\n            \"agent_card\": agent_data,\n            \"owner\": owner,\n            \"updated_at\": datetime.utcnow().isoformat()\n        }\n        \n        with open(agent_file, 'w', encoding='utf-8') as f:\n            json.dump(record, f, ensure_ascii=False, indent=2)\n        \n        return True\n    \n    def delete(self, name: str, organization: str, owner: str) -> bool:\n        key = (name.strip(), organization.strip())\n        stored_owner = self._index.get(key)\n        \n        if not stored_owner:\n            return False\n        \n        if stored_owner != owner:\n            raise PermissionError(f\"Agent belongs to {stored_owner}\")\n        \n        agent_file = self._get_agent_file(owner, name, organization)\n        if agent_file.exists():\n            agent_file.unlink()\n        \n        del self._index[key]\n        self._save_index()\n        \n        return True\n    \n    def find_by_owner(self, owner: str) -> List[AgentCard]:\n        \"\"\"查询特定owner的所有agent\"\"\"\n        owner_dir = self._get_owner_dir(owner)\n        agents = []\n        \n        for agent_file in owner_dir.glob(\"*.json\"):\n            with open(agent_file, 'r', encoding='utf-8') as f:\n                record = json.load(f)\n            agents.append(AgentCard(**record[\"agent_card\"]))\n        \n        return agents\n    \n    def _load_index(self):\n        \"\"\"加载索引\"\"\"\n        index_file = self.data_dir / \"index.json\"\n        if index_file.exists():\n            with open(index_file, 'r', encoding='utf-8') as f:\n                index_data = json.load(f)\n            for entry in index_data:\n                self._index[(entry[\"name\"], entry[\"organization\"])] = entry[\"owner\"]\n    \n    def _save_index(self):\n        \"\"\"保存索引\"\"\"\n        index_file = self.data_dir / \"index.json\"\n        index_data = [\n            {\"name\": k[0], \"organization\": k[1], \"owner\": v}\n            for k, v in self._index.items()\n        ]\n        with open(index_file, 'w', encoding='utf-8') as f:\n            json.dump(index_data, f, ensure_ascii=False, indent=2)\n```\n\n### 5.4 文件存储方案推荐\n\n| 场景 | 推荐方案 |\n|------|---------|\n| 少量owner (<10) | 方案A：单文件+owner字段，简单高效 |\n| 多owner + 物理隔离需求 | 方案B：按owner分目录 |\n| 需要平滑迁移 | 方案A，后续可迁移到方案B |\n\n**默认推荐方案A**，实现简单，兼容现有架构。\n\n---\n\n## 6. Handler改造设计\n\n### 6.1 InsertHandler改造\n\n```python\n# common/custom/custom_handle.py\nclass InsertHandler(Handler):\n    async def handle(self, agent: AgentCard, owner: str = None) -> bool:\n        \"\"\"注册Agent，携带owner\"\"\"\n        if owner is None:\n            owner = 'system'  # 默认owner\n        \n        registry = get_registry()\n        return registry.register(agent, owner=owner)\n```\n\n### 6.2 UpdateHandler改造\n\n```python\nclass UpdateHandler(Handler):\n    async def handle(self, name: str, organization: str, \n                     agent_data: dict, owner: str = None) -> bool:\n        \"\"\"更新Agent，携带owner校验\"\"\"\n        registry = get_registry()\n        return registry.update(name, organization, agent_data, owner=owner)\n```\n\n### 6.3 DeregisterHandler改造\n\n```python\nclass DeregisterHandler(Handler):\n    async def handle(self, name: str, organization: str, \n                     owner: str = None) -> bool:\n        \"\"\"注销Agent，携带owner校验\"\"\"\n        registry = get_registry()\n        return registry.deregister(name, organization, owner=owner)\n```\n\n### 6.4 GetHandler改造\n\n```python\nclass GetHandler(Handler):\n    async def handle(self, name: str, organization: str) -> Optional[Dict]:\n        \"\"\"查询Agent，返回包含owner的记录\"\"\"\n        registry = get_registry()\n        return registry.get_by_key(name, organization)\n```\n\n---\n\n## 7. RegistryCore改造\n\n```python\n# agent_registry/core.py\nclass RegistryCore:\n    \n    def register(self, agent: AgentCard, owner: str = 'system', \n                 use_vectordb: bool = USE_VECTORDB) -> bool:\n        \"\"\"注册Agent，携带owner\"\"\"\n        with self._lock:\n            if use_vectordb:\n                # vectordb模式：存储时包含owner\n                entity_str = json.dumps(MessageToDict(agent, preserving_proto_field_name=True))\n                embedding = self.embedding_tool.get_embedding_vector(agent.description)\n                id = self._make_id(agent.name, agent.provider.organization)\n                insert_entity = {\n                    \"embedding\": embedding,\n                    \"id\": id,\n                    \"name\": agent.name,\n                    \"description\": agent.description,\n                    \"organization\": agent.provider.organization,\n                    \"agent_card\": entity_str,\n                    \"owner\": owner  # 新增\n                }\n                insert_data = {\"collection_name\": COLLECTION_NAME, \"entity\": insert_entity}\n                return self.vectordb.insert_entity(insert_data)\n            elif self.persistence_mode == 'postgresql':\n                return self.storage.create(agent, owner)\n            else:\n                return self.storage.create(agent, owner)\n    \n    def get_by_key(self, name: str, organization: str, \n                   use_vectordb: bool = USE_VECTORDB) -> Optional[Dict]:\n        \"\"\"查询Agent，返回包含owner的记录\"\"\"\n        if use_vectordb:\n            query_data = {\"collection_name\": COLLECTION_NAME, \"key\": \"id\", \n                          \"value\": self._make_id(name, organization)}\n            results = self.vectordb.query_by_key(query_data)\n            if results:\n                result = results[0]\n                return {\n                    \"agent_card\": AgentCard(**result.get(\"agent_card\", {})),\n                    \"owner\": result.get(\"owner\", \"system\")\n                }\n            return None\n        elif self.persistence_mode == 'postgresql':\n            return self.storage.find_by_key(name, organization)\n        else:\n            return self.storage.find_by_key(name, organization)\n    \n    def update(self, name: str, organization: str, agent_data: Dict, \n               owner: str = 'system', use_vectordb: bool = USE_VECTORDB) -> bool:\n        \"\"\"更新Agent，携带owner校验\"\"\"\n        if use_vectordb:\n            # vectordb更新时校验owner\n            existing = self.get_by_key(name, organization)\n            if not existing or existing.get(\"owner\") != owner:\n                raise PermissionError(f\"Permission denied\")\n            # ... vectordb更新逻辑 ...\n        elif self.persistence_mode == 'postgresql':\n            return self.storage.update(name, organization, agent_data, owner)\n        else:\n            return self.storage.update(name, organization, agent_data, owner)\n    \n    def deregister(self, name: str, organization: str, owner: str = 'system',\n                   use_vectordb: bool = USE_VECTORDB) -> bool:\n        \"\"\"注销Agent，携带owner校验\"\"\"\n        if use_vectordb:\n            existing = self.get_by_key(name, organization)\n            if not existing or existing.get(\"owner\") != owner:\n                raise PermissionError(f\"Permission denied\")\n            # ... vectordb删除逻辑 ...\n        elif self.persistence_mode == 'postgresql':\n            return self.storage.delete(name, organization, owner)\n        else:\n            return self.storage.delete(name, organization, owner)\n```\n\n---\n\n## 8. 配置变更\n\n### 8.1 新增配置项\n\n```properties\n# etc/conf/persistence.conf 新增\n\n# Owner隔离开关\nowner.isolation.enabled=true\n\n# Owner校验严格模式\n# strict: 严格校验，无证书CN则拒绝\n# relaxed: 宽松模式，无CN时使用默认owner\nowner.validation.mode=strict\n\n# 默认owner（当无证书CN时使用）\nowner.default=system\n\n# 文件存储owner隔离模式\n# single_file: 单文件+owner字段\n# owner_split: 按owner分目录\nfile.storage.owner.mode=single_file\n```\n\n### 8.2 配置加载\n\n```python\n# agent_registry/config.py 新增\nOWNER_ISOLATION_ENABLED = get_conf().get('owner.isolation.enabled', 'true').lower() == 'true'\nOWNER_VALIDATION_MODE = get_conf().get('owner.validation.mode', 'strict')\nOWNER_DEFAULT = get_conf().get('owner.default', 'system')\nFILE_STORAGE_OWNER_MODE = get_conf().get('file.storage.owner.mode', 'single_file')\n```\n\n---\n\n## 9. 向量数据库改造（可选）\n\n若使用Milvus向量数据库，需扩展collection schema：\n\n```python\n# collection定义增加owner字段\nfields = [\n    FieldSchema(name=\"id\", dtype=DataType.VARCHAR, max_length=256, is_primary=True),\n    FieldSchema(name=\"embedding\", dtype=DataType.FLOAT_VECTOR, dim=1024),\n    FieldSchema(name=\"name\", dtype=DataType.VARCHAR, max_length=100),\n    FieldSchema(name=\"organization\", dtype=DataType.VARCHAR, max_length=100),\n    FieldSchema(name=\"description\", dtype=DataType.VARCHAR, max_length=1000),\n    FieldSchema(name=\"agent_card\", dtype=DataType.VARCHAR, max_length=65535),\n    FieldSchema(name=\"owner\", dtype=DataType.VARCHAR, max_length=100),  # 新增\n]\n\n# 创建owner索引\nindex_params = {\n    \"field_name\": \"owner\",\n    \"index_type\": \"Trie\",\n    \"metric_type\": \"UNKNOWN\"\n}\ncollection.create_index(\"owner\", index_params)\n```\n\n---\n\n## 10. 流程图\n\n### 10.1 注册流程\n\n```mermaid\nsequenceDiagram\n    participant Client as Agent Client\n    participant Proxy as Nginx/Proxy\n    participant API as FastAPI\n    participant Handler as InsertHandler\n    participant Storage as FileStorage/PostgreSQL\n    \n    Client->>Proxy: HTTPS + Client Cert\n    Proxy->>Proxy: 解析证书CN\n    Proxy->>API: POST /register<br/>Header: X-SSL-Client-CN=admin-001\n    API->>API: 校验CN格式\n    API->>API: 解析AgentCard\n    API->>Handler: handle(agent, owner=admin-001)\n    Handler->>Storage: create(agent, owner)\n    \n    alt PostgreSQL\n        Storage->>Storage: INSERT with owner\n    else FileStorage\n        Storage->>Storage: 写入记录+owner字段\n    end\n    \n    Storage-->>Handler: success\n    Handler-->>API: success\n    API-->>Client: 201 Created\n```\n\n### 10.2 更新/删除流程\n\n```mermaid\nsequenceDiagram\n    participant Client as Agent Client\n    participant API as FastAPI\n    participant Query as GetHandler\n    participant Storage as StorageBackend\n    \n    Client->>API: PUT /update<br/>Header: X-SSL-Client-CN=admin-001\n    API->>Query: find_by_key(name, org)\n    Query->>Storage: 查询agent\n    Storage-->>Query: {agent_card, owner: admin-001}\n    Query-->>API: agent_record\n    \n    API->>API: 校验 CN(admin-001) == owner(admin-001)\n    \n    alt 匹配成功\n        API->>Storage: update(name, org, data, owner)\n        Storage-->>API: success\n        API-->>Client: 200 OK\n    else 匹配失败\n        API-->>Client: 403 Forbidden<br/>Agent belongs to admin-002\n    end\n```\n\n---\n\n## 11. 测试设计\n\n| 测试用例 | 描述 |\n|---------|------|\n| test_cn_extraction | CN字段解析正确性 |\n| test_cn_validation | CN格式校验 |\n| test_register_with_owner | 注册携带owner |\n| test_update_owner_match | 更新时owner匹配成功 |\n| test_update_owner_mismatch | 更新时owner不匹配拒绝 |\n| test_delete_owner_match | 删除时owner匹配成功 |\n| test_delete_owner_mismatch | 删除时owner不匹配拒绝 |\n| test_file_storage_owner | 文件存储owner隔离 |\n| test_postgresql_storage_owner | PostgreSQL存储owner隔离 |\n| test_default_owner | 无证书CN时使用默认owner |\n\n---\n\n## 12. 文件清单\n\n### 新增文件\n\n| 文件路径 | 说明 |\n|---------|------|\n| `common/cert/cert_cn_parser.py` | CN解析工具 |\n| `agent_registry/persistence/file_storage_owner_split.py` | 按owner分目录存储（可选） |\n\n### 修改文件\n\n| 文件 | 改动 |\n|------|------|\n| `common/cert/cert_parser.py` | `_extract_certificate_info`增加CN提取 |\n| `common/cert/x509_obj.py` | `CertObj`增加cn属性 |\n| `agent_registry/persistence/base.py` | 接口增加owner参数 |\n| `agent_registry/persistence/file_storage.py` | 实现owner隔离 |\n| `agent_registry/persistence/postgresql_storage.py` | 实现owner隔离 |\n| `agent_registry/persistence/sql_queries.py` | 新增owner相关SQL |\n| `agent_registry/core.py` | 方法增加owner参数 |\n| `agent_registry/server.py` | 接口改造，提取和校验owner |\n| `common/custom/custom_handle.py` | Handler增加owner参数 |\n| `agent_registry/config.py` | 新增owner相关配置 |\n\n---\n\n## 13. 实现计划\n\n| 阶段 | 内容 | 优先级 |\n|------|------|--------|\n| 1 | CN解析工具 `cert_cn_parser.py` | P0 |\n| 2 | 证书解析集成（cert_parser/x509_obj） | P0 |\n| 3 | PostgreSQL表结构变更 | P0 |\n| 4 | StorageBackend接口扩展 | P0 |\n| 5 | PostgreSQL存储owner实现 | P0 |\n| 6 | 文件存储owner实现（方案A） | P0 |\n| 7 | Handler改造 | P0 |\n| 8 | RegistryCore改造 | P0 |\n| 9 | REST接口改造 | P0 |\n| 10 | 配置项新增 | P1 |\n| 11 | 文件存储方案B实现（可选） | P2 |\n| 12 | 向量数据库owner扩展（可选） | P2 |\n| 13 | 单元测试 | P0 |\n\n---\n\n## 14. 文件存储方案选择建议\n\n### 场景分析\n\n| 场景 | agent数量 | owner数量 | 推荐方案 |\n|------|----------|----------|---------|\n| 开发/测试环境 | <100 | <5 | 方案A：单文件 |\n| 小规模生产 | <1000 | <20 | 方案A：单文件 |\n| 大规模生产 | >1000 | >50 | 方案B：分目录 |\n| 安全合规要求高 | - | - | 方案B：分目录 |\n\n### 方案A详细说明\n\n**适用场景**：\n- 绝大多数场景（agent数量在max_file_size限制内）\n- 需要平滑迁移的存量系统\n- 查询性能要求高的场景（单文件索引更快）\n\n**实现要点**：\n- 每条记录增加 `owner` 字段\n- 读写时携带owner校验\n- 权限校验在业务层完成\n\n### 方案B详细说明\n\n**适用场景**：\n- agent数量巨大（超过单文件性能阈值）\n- 需要物理隔离的合规场景\n- 按owner备份/迁移需求\n\n**实现要点**：\n- 按owner创建独立目录\n- 维护全局索引（name+org → owner映射）\n- 目录权限设置（0o700）\n\n### 迁移路径\n\n```\n阶段1: 方案A（单文件+owner字段） → 系统上线\n阶段2: 数据量增长 → 监控性能\n阶段3: 达到阈值 → 迁移到方案B\n       迁移工具：读取单文件，按owner拆分到目录\n```\n\n---\n\n## 15. 安全注意事项\n\n1. **CN校验**：严格校验CN格式，防止注入\n2. **目录权限**：owner目录设置0o700，文件设置0o600\n3. **日志脱敏**：审计日志中owner脱敏处理\n4. **向后兼容**：存量数据默认owner='system'\n5. **代理信任**：X-SSL-Client-CN Header来源可信"
}
```

**Output:**
```
Wrote file successfully.
```

---

## Assistant (Build · GLM-5 · 8.4s)

_Thinking:_

设计文档已经编写完成。让我给用户一个简要的总结。

设计文档已创建：`owner-isolation-design.md`

**关键设计要点**：

1. **证书CN提取**：新增 `cert_cn_parser.py`，从Subject解析CN字段

2. **REST接口改造**：
   - 注册：从Header `X-SSL-Client-CN` 获取owner入库
   - 更新/删除：校验证书CN与库中owner匹配，不匹配返回403

3. **文件存储方案建议**：
   - **方案A（推荐）**：单文件存储 + 每条记录增加owner字段
     - 实现简单，改动小，查询高效
   - **方案B（可选）**：按owner分目录存储
     - 物理隔离，适合大数据量或合规场景
   - 默认推荐方案A，后续可平滑迁移到方案B

---

